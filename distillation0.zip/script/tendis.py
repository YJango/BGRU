import tensorflow as tf
import numpy as np
import math
from keras.utils import np_utils

#varible

NUM_STATES=120
window_size=17
N_EPOCHS = 100

PATH="/home/jango/distillation/"
np.random.seed(55)

def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def shufflelists(x,y,z):
    ri=np.random.permutation(len(x))
    x=x[ri]
    y=y[ri]
    z=z[ri]
    return x,y,z

#-------------------------------------------------load data 
skip=window_size / 2
#train data
inputs =np.load(PATH+"teacher/DnnFile/tea_train.npy")#[:,:39]
#make window
X_TRAIN=MakeWindows(inputs,window_size).astype('float32')

#load train targets
targets = np.load(PATH+"teacher/DnnFile/tea_train_target.npy")
Y_train=np_utils.to_categorical(targets,NUM_STATES)
Y_TRAIN=Y_train[skip:-skip].astype('int16')
#------------------------------------------------------------
#validation data
inputs =np.load(PATH+"teacher/DnnFile/tea_validation.npy")#[:,:39]
#make window
X_VALI=MakeWindows(inputs,window_size).astype('float32')

#load train targets
targets = np.load(PATH+"teacher/DnnFile/tea_validation_target.npy")
Y_validation=np_utils.to_categorical(targets,NUM_STATES)
Y_VALI=Y_validation[skip:-skip].astype('int16')

#soft targets
SOFT_TRAIN=np.load(PATH+"distrain/soft_targets/soft_train.npy").astype('float32')
SOFT_VALI=np.load(PATH+"distrain/soft_targets/soft_vali.npy").astype('float32')
#***********************************************************************
print "train_set:"
print X_TRAIN.shape
print Y_TRAIN.shape
print SOFT_TRAIN.shape
print "validation_set:"
print X_VALI.shape
print Y_VALI.shape
print SOFT_VALI.shape

def dnn(learningrate,lossvali,accvali,softvali,allvali,batch_size=32,N_HIDDEN=2048,LN=4,drp=0.2,readweights=False,patience=5,lamda=0.2,Tem=1.0):
    sess = tf.InteractiveSession()
    #variable holders---------------------------
    with tf.name_scope("input") as scope:
        x = tf.placeholder(tf.float32, [None, X_TRAIN.shape[1]],name='input')
    with tf.name_scope("hard_target") as scope:
        hard_target = tf.placeholder(tf.float32, [None, NUM_STATES],name='hard_target')
    with tf.name_scope("soft_input") as scope:
        s_ = tf.placeholder(tf.float32, [None, NUM_STATES],name='soft_input')
    with tf.name_scope("dropout_keep_prob") as scope:
        kp=tf.placeholder(tf.float32)
    with tf.name_scope("temperature") as scope:
        T=tf.placeholder(tf.float32)
    with tf.name_scope("lamda") as scope:
        L=tf.placeholder(tf.float32)
    global_step = tf.Variable(0, trainable=False)
    #5-------------------------------------------
    with tf.name_scope("hidden_1") as scope:
        W1 = tf.Variable(tf.truncated_normal([X_TRAIN.shape[1], N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden1_W')
        b1 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden1_b')
        y1 = tf.nn.relu(tf.matmul(x, W1) + b1)
        #tf.histogram_summary('W1', W1)
        #tf.histogram_summary('b1', b1)
    d1=tf.nn.dropout(y1,kp)
    with tf.name_scope("hidden_2") as scope:
        W2 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden2_W')
        b2 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden2_b')
        y2 = tf.nn.relu(tf.matmul(d1, W2) + b2)
        #tf.histogram_summary('W2', W2)
        #tf.histogram_summary('b2', b2)
    d2=tf.nn.dropout(y2,kp)
    with tf.name_scope("hidden_3") as scope:
        W3 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden3_W')
        b3 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden3_b')
        y3 = tf.nn.relu(tf.matmul(d2, W3) + b3)
        #tf.histogram_summary('W3', W3)
        #tf.histogram_summary('b3', b3)
    d3=tf.nn.dropout(y3,kp)
    with tf.name_scope("hidden_4") as scope:
        W4 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden4_W')
        b4 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden4_b')
        y4 = tf.nn.relu(tf.matmul(d3, W4) + b4)
        #tf.histogram_summary('W4', W4)
        #tf.histogram_summary('b4', b4)
    d4=tf.nn.dropout(y4,kp)
    with tf.name_scope("hidden_5") as scope:
        W5 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden5_W')
        b5 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden5_b')
        y5 = tf.nn.relu(tf.matmul(d4, W5) + b5)

    d5=tf.nn.dropout(y5,kp)
    with tf.name_scope("hidden_5") as scope:
        W6 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden5_W')
        b6 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden5_b')
        y6 = tf.nn.relu(tf.matmul(d5, W6) + b6)
    d6=tf.nn.dropout(y6,kp)
    with tf.name_scope("out_layer") as scope:
        W = tf.Variable(tf.truncated_normal([N_HIDDEN, NUM_STATES],stddev=1.0 / math.sqrt(float(NUM_STATES))),name='outlayer_W')
        b = tf.Variable(tf.constant(0.001,shape=[NUM_STATES]),name='outlayer_b')
        y=tf.matmul(d6, W) + b
        #tf.histogram_summary('W', W)
        #tf.histogram_summary('b', b)
    with tf.name_scope("hard_output") as scope:
        hard_output= tf.nn.softmax(y)#tf.exp((y-tf.reduce_max(y)))/tf.reduce_sum(tf.exp((y-tf.reduce_max(y))), 1, keep_dims=True)
        #tf.histogram_summary('hard_output', hard_output)
    with tf.name_scope("soft_output") as scope:
        soft_output= tf.nn.softmax(y/T)#tf.exp((y-tf.reduce_max(y))/T)/tf.reduce_sum(tf.exp((y-tf.reduce_max(y))/T), 1, keep_dims=True)
        #tf.histogram_summary('soft_output', soft_output)
    with tf.name_scope("soft_target") as scope:
        soft_target= tf.nn.softmax(s_/T)#tf.exp((s_-tf.reduce_max(s_))/T)/tf.reduce_sum(tf.exp((s_-tf.reduce_max(s_))/T), 1, keep_dims=True)
        #tf.histogram_summary('soft_target', soft_target)
    with tf.name_scope("L2"):
        L2=tf.nn.l2_loss(W1)+tf.nn.l2_loss(W2)+tf.nn.l2_loss(W3)+tf.nn.l2_loss(W4)+tf.nn.l2_loss(W5)+tf.nn.l2_loss(W6)+tf.nn.l2_loss(W)
        #tf.histogram_summary('L2', L2)
    with tf.name_scope("hard_loss") as scope:
        hardloss= -tf.reduce_sum(hard_target*tf.log(tf.clip_by_value(hard_output,1e-25,1.0)))
        h_loss=tf.scalar_summary('hard_loss', hardloss)
    with tf.name_scope("soft_loss") as scope:
        softloss=-tf.reduce_sum(soft_target*tf.log(tf.clip_by_value(soft_output,1e-25,1.0)))
        s_loss=tf.scalar_summary('soft_loss', softloss)
    with tf.name_scope("weighted_losses") as scope:
        allloss=hardloss * (1-L) + softloss*L*T*T+L2*1e-2
        a_loss=tf.scalar_summary('total_loss', allloss)
    with tf.name_scope("Accuracy") as scope:
        accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(hard_output,1), tf.argmax(hard_target,1)), tf.float32))
        accuracysum=tf.scalar_summary('accuracy', accuracy)
    learning_rate = tf.train.exponential_decay(learningrate, global_step,913342*2/batch_size, 0.99, staircase=0)
    tf.scalar_summary('learning_rate', learning_rate)
    with tf.name_scope("trainer") as scope:
        train_step = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(allloss,global_step=global_step)
        #train_step = tf.train.RMSPropOptimizer(learningrate,decay=0.9, momentum=0.9,epsilon=1e-9).minimize(allloss,global_step=global_step)

    #shuffle
    X,Y,S = shufflelists(X_TRAIN,Y_TRAIN,SOFT_TRAIN)
    
    print X.shape,Y.shape,S.shape
    
    train_writer = tf.train.SummaryWriter("train",sess.graph)
    test_writer = tf.train.SummaryWriter("test")
    init = tf.initialize_all_variables()
    merged = tf.merge_all_summaries()
    
    if readweights==0:
        sess.run(init)
        saver = tf.train.Saver()
    else:
        sess.run(init)
        saver = tf.train.Saver()
        fname=PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.ckpt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
        saver.restore(sess, fname)


    print 'start training...'
    batch_idx = 0
    epoch = 0
    p=1
    while epoch < N_EPOCHS:
        summary, _ = sess.run([merged, train_step],feed_dict={x:X[batch_idx:batch_idx + batch_size],hard_target:Y[batch_idx:batch_idx + batch_size],s_:S[batch_idx:batch_idx + batch_size],kp:drp,T:Tem,L:lamda})
        train_writer.add_summary(summary, global_step.eval())
        batch_idx += batch_size
        if batch_idx >= X_TRAIN.shape[0]:
            batch_idx=0
            epoch += 1
            summary, acc ,loss,soft_loss,all_loss= sess.run([merged, accuracy,hardloss,softloss,allloss], feed_dict={x:X_VALI,hard_target:Y_VALI,s_:SOFT_VALI,kp:1,T:Tem,L:lamda})
            test_writer.add_summary(summary, global_step.eval())
            print ('vali acc:%s, vali loss:%s, vali soft loss:%s all_loss:%s' %(acc,loss,soft_loss,all_loss))
            if lossvali>loss:
                fname=PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.ckpt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
                save_path = saver.save(sess, fname)
                print('saved')
                f=open(PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.txt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda)),'a')
                f.write('vali acc:%s, vali loss:%s, vali soft loss:%s all_loss:%s' %(acc,loss,soft_loss,all_loss))
                f.close()
                lossvali=loss
                accvali=acc
                allvali=all_loss
                softvali=soft_loss
                p=1
            else:
                p+=1
                fname=PATH+('distrain/weights/bad_T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.ckpt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
                save_path = saver.save(sess, fname)
                if p>patience:
                    sess.close()
                    return lossvali
            #shuffle
            X,Y,S = shufflelists(X_TRAIN,Y_TRAIN,SOFT_TRAIN)

def train(ilr=1e-2,elr=1e-6,batch_size=64,N_HIDDEN=2048,LN=4,times=0,drp=0.1,patience=3,lamda=0.2,Tem=1.0):
    lossvali=100000000
    softvali=100000000
    allvali=100000000
    accvali=0
    rate=ilr
    if times==0:
        f=open(PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.txt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda)),'w')
        f.write('learningrate starts from %s\n' %rate)
        f.write('layers:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,drp,batch_size))
        f.close()
    print 'learningrate starts from %s' %rate
    while rate>elr:
        if times==0:
            readweights=0
        else :
            readweights=True
        lossvali=dnn(rate,lossvali,accvali,softvali,allvali,batch_size,N_HIDDEN,LN,drp,readweights,patience=patience,lamda=lamda,Tem=Tem)
        times+=1
train(ilr=1e-5,elr=1e-7,batch_size=128,N_HIDDEN=3072,LN=6,times=1,drp=0.4,patience=100,lamda=0,Tem=1)
