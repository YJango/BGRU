import numpy as np
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
from keras.utils import np_utils
from HTKRW import openx
import theano
import theano.tensor as T
import lasagne
import struct

PATH="/home/jango/distillation"
DIC=PATH+"/shared_babel/phone.dic"
LM=PATH+"/shared_babel/pdnet"
HLIST=PATH+"/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"
NUM_STATES=120
window_size=17
N_EPOCHS = 200
def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def write_htk(features,outputFileName,fs=100,dt=9):
    sampPeriod = 1./fs
    pk =dt & 0x3f
    features=np.atleast_2d(features)
    if pk==0:
        features =features.reshape(-1,1)
    with open(outputFileName,'wb') as fh:
        fh.write(struct.pack(">IIHH",len(features),sampPeriod*1e7,features.shape[1]*4,dt))
        features=features.astype(">f")
        features.tofile(fh)

def RecogWithStateProbs(typ,s=2,pl=2):
    MODEL=PATH+"/teacher/HMM/hmmdefs"# %typ
    testlist=PATH+"/%s/feature/list/testdnn.list" %typ

    cmd='echo | julius-4.3.1 -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s %s' %(testlist, HLIST, MODEL, LM, DIC, OPT, s, pl,"-input outprob")
    result=check_output(cmd,shell=1).split("\n")
    #print cmd
    
    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/DNNRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd='HResults -A -z ::: -I '+PATH+'/shared_babel/mlf/alignedtest.mlf -e ::: s_s -e ::: s_e %s /home/jango/distillation/%s/DNNRec/rec.mlf' %(HLIST,typ)
    acc=check_output(cmd,shell=1)
    print acc
    PER=100-float(acc.split("\n")[-3].split(" ")[2].split("=")[1])
    
    print "%s    s: %s, p: %s, PER: %s" %(typ,s,pl,PER)
    return PER

def dnn(typ='student',batch_size=32,N_HIDDEN=2048,LN=4,drp=0.2,patience=5):

    #------------------------------------------------------------
    #validation data
    skip=window_size/2
    inputs =np.load(PATH+"/teacher/DnnFile/tea_test.npy")[:,:39]
    #make window
    X_VALI=MakeWindows(inputs,window_size).astype('float32')

    #load train targets
    targets = np.load(PATH+"/teacher/DnnFile/tea_test_target.npy")
    Y_validation=np_utils.to_categorical(targets,NUM_STATES)
    Y_VALI=Y_validation[skip:-skip].astype('int16')

    hard_targets = T.imatrix('hard_target')

    l_in = lasagne.layers.InputLayer(shape=(None, X_VALI.shape[1]))
    #
    l_hidden = lasagne.layers.DenseLayer(
        l_in,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d=lasagne.layers.dropout(l_hidden,drp)
    l_hidden2 = lasagne.layers.DenseLayer(
        d,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d2=lasagne.layers.dropout(l_hidden2,drp)
    l_hidden3 = lasagne.layers.DenseLayer(
        d2,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d3=lasagne.layers.dropout(l_hidden3,drp)
    l_hidden4 = lasagne.layers.DenseLayer(
        d3,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d4=lasagne.layers.dropout(l_hidden4,drp)
    l_hidden5 = lasagne.layers.DenseLayer(
        d4,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d5=lasagne.layers.dropout(l_hidden5,drp)
    l_hidden6 = lasagne.layers.DenseLayer(
        d5,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d6=lasagne.layers.dropout(l_hidden6,drp)
    if LN==3:
        go_in=d3
    elif LN==4:
        go_in=d4
    elif LN==5:
        go_in=d5
    elif LN==6:
        go_in=d6
    else:
        print 'wrong layers number'
    l_out = lasagne.layers.DenseLayer(
        go_in, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.softmax)

    hard_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=True), hard_targets))

    all_params = lasagne.layers.get_all_params(l_out)

    #output of network
    get_train=theano.function([l_in.input_var],lasagne.layers.get_output(l_out, deterministic=True))
    #acc for hard
    get_acc = theano.function([l_in.input_var,hard_targets], T.mean(lasagne.objectives.categorical_accuracy(lasagne.layers.get_output(l_out, deterministic=True), hard_targets)))
    #get two losses
    get_loss = theano.function([l_in.input_var,hard_targets], hard_loss_eval)

    fname=PATH+('/%s/DnnWeight_helpART/stu' %typ+'_%dL%d_drp%s_batch%d.npy' %(LN,N_HIDDEN,drp,batch_size))
    weights=np.load(fname)
    lasagne.layers.set_all_param_values(l_out, weights)
    
    acc=get_acc(X_VALI,Y_VALI)
    loss=get_loss(X_VALI,Y_VALI)
    f=open(fname[:-4],"r")
    al=f.read()
    f.close()
    return get_train,round(acc,4)*100,round(loss,3),len(al.split("vali acc:"))-1

def GetStateProbs(typ,batch_size=256,N_HIDDEN=1024,LN=4,drp=0.2):

    #load state priors
    priors=dict([line.split() for line in open(PATH+"/teacher/StatPrior_train").readlines()])
    #change datatype
    priors=dict([(int(a),float(b)) for a, b in priors.items()])
    #turn into 1D vector in order
    priors=np.array([priors[i] for i in range(len(priors))])
    #get file list
    fnames=open(PATH+"/%s/feature/list/testmfc.list" %typ).readlines()
    #
    #loop all files in filelist
    get_train,acc,loss,e=dnn(batch_size=batch_size,N_HIDDEN=N_HIDDEN,LN=LN,drp=drp)

    for name in fnames:
        #print name[:-1]
        fmfc=openx(name[:-1],'rb',veclen=39)
        data=fmfc.getall()
        #make windows
        vecs=MakeWindows(data,17)
        vecs=vecs.astype('float32')
        #get result from DNN
        probs=get_train(vecs)
        #turn into likelihoods
        log_liks=np.log10(probs/priors)
        #print log_liks.shape
        prob_path=PATH+"/%s/StatePro/" %typ+name.split("/")[-1][:-4]+"llk"
        #print prob_path
        write_htk(log_liks,prob_path)
    PER=RecogWithStateProbs(typ,2,2)
    print "PER:",PER,"acc:",acc,"loss",loss,"epoch:",e
    return PER,acc,loss,e

fw=open("studentARThelped.txt","w")
for l in [3,4,5]:
    for n in [1024,2048,3072]:
        for b in [128,256,512]:
            for d in [0.1,0.2,0.3,0.4]:
                PER,acc,loss,e=GetStateProbs("student",batch_size=b,N_HIDDEN=n,LN=l,drp=d)
                text='l %s,n %s,b %s,d %s,PER %s,acc %s,loss %s,e %s\n' %(l,n,b,d,PER,acc,loss,e)
                fw.write(text)
for n in [1024]:
    for b in [128,256,512]:
        for d in [0.1,0.2,0.3,0.4]:
            PER,acc,loss,e=GetStateProbs("student",batch_size=b,N_HIDDEN=n,LN=6,drp=d)
            text='l %s,n %s,b %s,d %s,PER %s,acc %s,loss %s,e %s\n' %(l,n,b,d,PER,acc,loss,e)
            fw.write(text)
for d in [0.1,0.2,0.3]:
    PER,acc,loss,e=GetStateProbs("student",batch_size=128,N_HIDDEN=2048,LN=6,drp=d)
    text='l %s,n %s,b %s,d %s,PER %s,acc %s,loss %s,e %s\n' %(l,n,b,d,PER,acc,loss,e)
    fw.write(text)
fw.close()
