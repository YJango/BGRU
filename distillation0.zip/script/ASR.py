import numpy as np
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
from HTKRW import openx
import struct

class ASR(object):
    """
    ASR functions

    """
    def __init__(self, learning_rate, drop_out, Layers, N_hidden, D_input, D_out, Task_type='regression', L2_lambda=0.0, _EPSILON=1e-12):
    
    def write_htk(self, features,outputFileName,fs=100,dt=9):
        sampPeriod = 1./fs
        pk =dt & 0x3f
        features=np.atleast_2d(features)
        if pk==0:
            features =features.reshape(-1,1)
        with open(outputFileName,'wb') as fh:
            fh.write(struct.pack(">IIHH",len(features),sampPeriod*1e7,features.shape[1]*4,dt))
            features=features.astype(">f")
            features.tofile(fh)
