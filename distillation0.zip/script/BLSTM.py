import theano
import theano.tensor as T
import lasagne
import numpy as np
from keras.utils import np_utils
#****************************************************************************************
PATH="/home/jango/distillation"
MODEL='teacher'
TIMESTEP=45
NUM_STATES=120
WINDOW_SIZE=17
N_EPOCHS = 20
np.random.seed(55)
if MODEL=="teacher":
    N_INPUT=87
else:
    N_INPUT=39
#****************************************************************************************
def get_acc_loss(get_out):
    print "vali loss and acc"
    real=T.matrix('real')
    prediction=T.matrix('prediction')
    vali_acc = theano.function([prediction,real], T.mean(lasagne.objectives.categorical_accuracy(prediction, real)))
    vali_loss = theano.function([prediction,real], T.mean(lasagne.objectives.categorical_crossentropy(prediction, real)))
    #read validation data
    X_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_lstm.npy" %MODEL[:3])
    Y_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_target.npy" %MODEL[:3])
    Y_VALI=np_utils.to_categorical(Y_VALI,NUM_STATES).astype('int16')
    return vali_acc(all_predictions(X_VALI,get_out),Y_VALI),vali_loss(all_predictions(X_VALI,get_out),Y_VALI)
    
def run_batch(X,time_steps=TIMESTEP):
    s_len=X.shape[0]
    input_dim=X.shape[1]
    n_batch=s_len/time_steps
    if (s_len%time_steps)==0:
        last_batch=None
        cut=None
    else:
        last_batch=s_len%time_steps
        cut=-1*(time_steps-last_batch)
    batch_X=np.array(X[0:n_batch*time_steps,:]).reshape((-1,time_steps,input_dim))
    m=np.ones((batch_X.shape[0],batch_X.shape[1]))
    if last_batch!=None:
        m_vector=np.hstack((np.ones((1,last_batch)),np.zeros((1,time_steps-last_batch))))
        m=np.vstack((m,m_vector))
        batch_x=X[(n_batch)*time_steps:,:]
        batch_x=np.vstack([batch_x,np.zeros((time_steps-last_batch,input_dim))])
        batch_X=np.vstack([batch_X,batch_x.reshape((1,time_steps,input_dim))])
    return batch_X.astype('float32'),m.astype('int16'),cut

def all_predictions(X,get_out):
    batch_x,mask,cut=run_batch(X[0],TIMESTEP)
    allpy=list()
    for x in X:
        batch_x,mask,cut=run_batch(x,TIMESTEP)
        allpy.append(get_out(batch_x,mask)[:cut])
    return np.concatenate(allpy).astype("float32")

def shuffle2lists(n):
    X=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_X_train%d_lstm.npy" %(TIMESTEP,MODEL[:3],n))
    Y=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_y_train%d_lstm.npy" %(TIMESTEP,MODEL[:3],n))
    ri=np.random.permutation(len(X))
    return X[ri],Y[ri].reshape((-1,Y.shape[-1]))
#****************************************************************************************
def blstm(learningrate,lossvali,accvali,B=128,N_HIDDEN=2048,drp=0.2,readweights=False,patience=3):
    #variable holders
    hard_targets = T.imatrix('hard_target')
    print "build model"
    #network
    #input layer
    l_in = lasagne.layers.InputLayer(shape=(None, None, N_INPUT*WINDOW_SIZE))
    l_mask = lasagne.layers.InputLayer(shape=(None, None))
#--------------------------parameters of LSTM----------
    gate_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(0.))
    cell_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        W_cell=None, b=lasagne.init.Constant(0.),
        nonlinearity=lasagne.nonlinearities.tanh)
#--------------------reshape--for Feedforward layer--------------------
    n_batch, n_time_steps, n_features = l_in.input_var.shape
    l_reshape0 = lasagne.layers.ReshapeLayer(l_in, (-1, N_INPUT))
#--------------------------Feedforward layer----------------------
    l_dense0 = lasagne.layers.DenseLayer(
        l_reshape0, N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),nonlinearity=lasagne.nonlinearities.rectify)
#--------------------reshape--for BLSTM--------------------
    l_out0 = lasagne.layers.ReshapeLayer(l_dense0, (-1,n_time_steps, N_HIDDEN))
    d1=lasagne.layers.dropout(l_out0,drp)
#-------------------------BLSTM-------------------------
    l_lstm = lasagne.layers.recurrent.LSTMLayer(
        d1, N_HIDDEN,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True)
#----------------------
    l_lstm_back = lasagne.layers.recurrent.LSTMLayer(
        l_out0, N_HIDDEN, ingate=gate_parameters,
        mask_input=l_mask, 
        forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=True)
    l_sum2 = lasagne.layers.ElemwiseSumLayer([l_lstm, l_lstm_back])
    d2=lasagne.layers.dropout(l_sum2,drp)
#--------------------------BLSTM2-------------------------
    l_lstm2 = lasagne.layers.recurrent.LSTMLayer(
        d2, N_HIDDEN,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100.)
    l_lstm_back2 = lasagne.layers.recurrent.LSTMLayer(
        l_sum2, N_HIDDEN, ingate=gate_parameters,
        mask_input=l_mask, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=True)
    l_sum = lasagne.layers.ElemwiseSumLayer([l_lstm2, l_lstm_back2])
#-------------------------------reshape--for Feedforward layer--------------------
    l_reshape1 = lasagne.layers.ReshapeLayer(l_sum, (-1, N_HIDDEN))
#-------------------------------dropout layer--------------------
    d3=lasagne.layers.dropout(l_reshape1,drp)
#-------------------------------Feedforward layer for output--------------------
    l_out = lasagne.layers.DenseLayer(
        l_reshape1, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.softmax)
#----------------------------------------------------------------------------------------
    loss_train = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=False), hard_targets))
    loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=True), hard_targets))

    all_params = lasagne.layers.get_all_params(l_out)
    #updates = lasagne.updates.nesterov_momentum(loss_train, all_params,learning_rate=learningrate)
    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=learningrate)
    #updates = lasagne.updates.rmsprop(loss_train, all_params,learning_rate=learningrate)

    train = theano.function([l_in.input_var, hard_targets, l_mask.input_var], loss_train, updates=updates)
    #output of network
    get_out=theano.function([l_in.input_var, l_mask.input_var],lasagne.layers.get_output(l_out, deterministic=True))

       
#restore params--------------------------------------------------------------------
    if readweights==True:
        fname=PATH+"/"+MODEL+('/LSTMWeight/%s_%d_drp%s_batch%d.npy' %(MODEL[:3],N_HIDDEN,drp,batch_size))
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)
    p=1 #patience
    print('start train')
    for i in range(N_EPOCHS):
        #half of train set
        b=0
        order=np.random.permutation(2)+1
        batch_x,batch_y=shuffle2lists(order[0])
        print "1st train set:"
        print(batch_x.shape)
        print(batch_y.shape)
        while b <len(batch_x):
            train(batch_x[b:b+B],batch_y[b*TIMESTEP:(b+B)*TIMESTEP],np.ones((len(batch_x[b:b+B]),TIMESTEP)).astype('int16'))
            b=b+B
        #the other half
        b=0
        batch_x,batch_y=shuffle2lists(order[1])
        print "2nd train set:"
        print(batch_x.shape)
        print(batch_y.shape)
        while b <len(batch_x):
            train(batch_x[b:b+B],batch_y[b*TIMESTEP:(b+B)*TIMESTEP],np.ones((len(batch_x[b:b+B]),TIMESTEP)).astype('int16'))
            b=b+B
        acc,loss=get_acc_loss(get_out)
        print ('vali acc:%s, vali loss:%s' %(acc,loss))
#save weights------------------------------------------------------
        if loss<lossvali:
            fname=PATH+"/"+MODEL+('/LSTMWeight/%s_%d_drp%s_batch%d.npy' %(MODEL[:3],N_HIDDEN,drp,B))
            weights = lasagne.layers.get_all_param_values(l_out)
            np.save(fname,weights)
            print('saved')
            f=open(fname[:-4],'a')
            f.write('vali acc:%s, vali loss:%s\n' %(acc,loss))
            f.close()
            lossvali=loss
            accvali=acc
            p=1
        else:
            p+=1
            if p>patience:
                return lossvali,accvali
#****************************************************************************************
def train(ilr=1e-4,elr=1e-6,batch_size=128,N_HIDDEN=2048,drp=0.5,patience=3):
    lossvali=100
    accvali=0
    rate=ilr
    f=open(PATH+"/"+MODEL+'/LSTMWeight/%s_%d_drp%s_batch%d' %(MODEL[:3],N_HIDDEN,drp,batch_size),'w')
    f.write('learningrate starts from %s\n' %rate)
    f.write('layers:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,drp,batch_size))
    f.close()
    print 'learningrate starts from %s' %rate
    times=0
    while rate>elr:
        if times==0:
            readweights=0
        else :
            readweights=1
        lossvali,accvali=blstm(rate,lossvali,accvali,batch_size,N_HIDDEN,drp,readweights,patience=patience)
        rate=rate*0.1
        print 'learningrate:%s'%rate
        times+=1

#run code

train(ilr=1e-4,elr=1e-7,batch_size=256,N_HIDDEN=2048,drp=0.5,patience=2)
train(ilr=1e-4,elr=1e-7,batch_size=256,N_HIDDEN=2048,drp=0.5,patience=2)
