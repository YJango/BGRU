import os,sys
path="/home/jango/distillation/script/"



#for n in [0,1,2,3,4,5,6]:
#    c="python %steacherDNN.py %s" %(path,n)
#    print c
#    os.system(c)
#    c="python %steacherSoft.py %s" %(path,n)
#    print c
##    os.system(c)
#    c="python %steacherSoftvali.py %s" %(path,n)
#    print c
#    os.system(c)

for t in [1.0,2.0]:
    for l in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]:
        for n in [1,2,3,4,5,6]:
            c="python %sDISALLall2.py %s %s %s" %(path,n,t,l)
            print c
            os.system(c)
