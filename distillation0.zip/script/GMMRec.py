import numpy as np
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
PATH="/home/jango/distillation"
DIC=PATH+"/shared_babel/phone.dic"
LM=PATH+"/shared_babel/pdnet"
HLIST=PATH+"/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"

def Recognition(typ,s,pl):
    MODEL=PATH+"/%s/HMM/hmmdefs" %typ
    testlist=PATH+"/%s/feature/list/testmfc.list" %typ

    #recognize using julius
    cmd='echo | julius-4.3.1 -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s' %(testlist, HLIST, MODEL, LM, DIC, OPT, s, pl)
    result=check_output(cmd,shell=1).split("\n")

    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/GMMRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd='HResults -A -z ::: -I '+PATH+'/shared_babel/mlf/alignedtest.mlf -e ::: s_s -e ::: s_e %s /home/jango/distillation/%s/GMMRec/rec.mlf' %(HLIST,typ)
    acc=check_output(cmd,shell=1)
    print acc
    PER=100-float(acc.split("\n")[-3].split(" ")[2].split("=")[1])
    print "%s    s: %s, p: %s, PER: %s" %(typ,s,pl,PER)

Recognition('teacher',7,1)
Recognition('student',7,1)
#Recognition('teacher75D',7,2)
