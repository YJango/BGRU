import tensorflow as tf
import numpy as np
import math
from keras.utils import np_utils
from tensorflow.python.ops.constant_op import constant
from tensorflow.models.rnn import rnn, rnn_cell

#varible

PATH="/home/jango/distillation"
MODEL='teacher'
TIMESTEP=45
NUM_STATES=120
WINDOW_SIZE=17
N_EPOCHS = 20
np.random.seed(55)
if MODEL=="teacher":
    N_INPUT=87
else:
    N_INPUT=39
#****************************************************************************************
def get_acc_loss(get_out):
    print "vali loss and acc"
    real=T.matrix('real')
    prediction=T.matrix('prediction')
    vali_acc = theano.function([prediction,real], T.mean(lasagne.objectives.categorical_accuracy(prediction, real)))
    vali_loss = theano.function([prediction,real], T.mean(lasagne.objectives.categorical_crossentropy(prediction, real)))
    #read validation data
    X_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_lstm.npy" %MODEL[:3])
    Y_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_target.npy" %MODEL[:3])
    Y_VALI=np_utils.to_categorical(Y_VALI,NUM_STATES).astype('int16')
    return vali_acc(all_predictions(X_VALI,get_out),Y_VALI),vali_loss(all_predictions(X_VALI,get_out),Y_VALI)
    
def run_batch(X,time_steps=TIMESTEP):
    s_len=X.shape[0]
    input_dim=X.shape[1]
    n_batch=s_len/time_steps
    if (s_len%time_steps)==0:
        last_batch=None
        cut=None
    else:
        last_batch=s_len%time_steps
        cut=-1*(time_steps-last_batch)
    batch_X=np.array(X[0:n_batch*time_steps,:]).reshape((-1,time_steps,input_dim))
    m=np.ones((batch_X.shape[0],batch_X.shape[1]))
    if last_batch!=None:
        m_vector=np.hstack((np.ones((1,last_batch)),np.zeros((1,time_steps-last_batch))))
        m=np.vstack((m,m_vector))
        batch_x=X[(n_batch)*time_steps:,:]
        batch_x=np.vstack([batch_x,np.zeros((time_steps-last_batch,input_dim))])
        batch_X=np.vstack([batch_X,batch_x.reshape((1,time_steps,input_dim))])
    return batch_X.astype('float32'),m.astype('int16'),cut

def all_predictions(X,get_out):
    batch_x,mask,cut=run_batch(X[0],TIMESTEP)
    allpy=list()
    for x in X:
        batch_x,mask,cut=run_batch(x,TIMESTEP)
        allpy.append(get_out(batch_x,mask)[:cut])
    return np.concatenate(allpy).astype("float32")

def shuffle2lists(n):
    X=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_X_train%d_lstm.npy" %(TIMESTEP,MODEL[:3],n))
    Y=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_y_train%d_lstm.npy" %(TIMESTEP,MODEL[:3],n))
    ri=np.random.permutation(len(X))
    return X[ri],Y[ri].reshape((-1,Y.shape[-1]))


def blstm(learningrate,lossvali,accvali,softvali,allvali,B=32,N_HIDDEN=2048,LN=4,drp=0.2,readweights=False,patience=5,lamda=0.2,Tem=1.0):
    sess = tf.InteractiveSession()
    #variable holders---------------------------
    with tf.name_scope("input") as scope:
        x = tf.placeholder(tf.float32, [None, TIMESTEP,N_INPUT],name='input')
    with tf.name_scope("hard_target") as scope:
        hard_target = tf.placeholder(tf.float32, [None, NUM_STATES],name='hard_target')
    with tf.name_scope("soft_input") as scope:
        s_ = tf.placeholder(tf.float32, [None, NUM_STATES],name='soft_input')
    with tf.name_scope("dropout_keep_prob") as scope:
        kp=tf.placeholder(tf.float32)
    with tf.name_scope("temperature") as scope:
        T=tf.placeholder(tf.float32)
    with tf.name_scope("lamda") as scope:
        L=tf.placeholder(tf.float32)
    global_step = tf.Variable(0, trainable=False)
    with tf.name_scope("istate") as scope:
        istate_fw = tf.placeholder("float", [None, N_HIDDEN])
        istate_bw = tf.placeholder("float", [None, N_HIDDEN])
    #5-------------------------------------------
    with tf.name_scope("reshape for ff") as scope:
        x1 = tf.reshape(x, [-1, N_INPUT]) 
    with tf.name_scope("hidden_1") as scope:
        W1 = tf.Variable(tf.truncated_normal([N_INPUT, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden1_W')
        b1 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden1_b')
        y1 = tf.nn.relu(tf.matmul(x1, W1) + b1)
        #tf.histogram_summary('W1', W1)
        #tf.histogram_summary('b1', b1)
    d1=tf.nn.dropout(y1,kp)
    with tf.name_scope("reshape for blstm") as scope:
        x2 = tf.reshape(d1, [-1, N_INPUT])

    with tf.name_scope("blstm1") as scope:
# Define weights
        weights1 = {
    'hidden': tf.Variable(tf.random_normal([N_INPUT, N_HIDDEN])),
    'out': tf.Variable(tf.random_normal([N_HIDDEN, NUM_STATES]))}
        biases1 = {
    'hidden': tf.Variable(tf.random_normal([N_HIDDEN])),
    'out': tf.Variable(tf.random_normal([NUM_STATES]))}
        l1 = tf.matmul(x2, weights1['hidden']) + biases1['hidden']
        l1 = tf.split(0, TIMESTEP, l1)
        lstm_fw_cell1 = rnn_cell.BasicLSTMCell(N_HIDDEN/2, forget_bias=1.0)
        lstm_bw_cell1 = rnn_cell.BasicLSTMCell(N_HIDDEN/2, forget_bias=1.0)
        blstm1 = rnn.bidirectional_rnn(lstm_fw_cell1, lstm_bw_cell1, l1,
                                             initial_state_fw=istate_fw,
                                             initial_state_bw=istate_bw)
    blstm1 = tf.matmul(blstm1[-1], weights1['out']) + biases1['out']
    d2=tf.nn.dropout(blstm1,kp)
    with tf.name_scope("blstm2") as scope:
        weights2 = {
    # Hidden layer weights => 2*n_hidden because of foward + backward cells
    'hidden': tf.Variable(tf.random_normal([N_INPUT, N_HIDDEN])),
    'out': tf.Variable(tf.random_normal([N_HIDDEN, NUM_STATES]))
}
        biases2 = {
    'hidden': tf.Variable(tf.random_normal([N_HIDDEN])),
    'out': tf.Variable(tf.random_normal([NUM_STATES]))
}
        l2 = tf.matmul(d2, weights2['hidden']) + biases2['hidden']
        lstm_fw_cell2 = rnn_cell.BasicLSTMCell(N_HIDDEN/2, forget_bias=1.0)
        lstm_bw_cell2 = rnn_cell.BasicLSTMCell(N_HIDDEN/2, forget_bias=1.0)
        blstm2 = rnn.bidirectional_rnn(lstm_fw_cell2, lstm_bw_cell2, l2,
                                             initial_state_fw=istate_fw,
                                             initial_state_bw=istate_bw)
    d3=tf.nn.dropout(blstm2,kp)
    with tf.name_scope("reshape for outlayer") as scope:
        x3 = tf.reshape(d3, [-1, N_INPUT]) 
    with tf.name_scope("out_layer") as scope:
        W = tf.Variable(tf.truncated_normal([N_HIDDEN, NUM_STATES],stddev=1.0 / math.sqrt(float(NUM_STATES))),name='outlayer_W')
        b = tf.Variable(tf.constant(0.001,shape=[NUM_STATES]),name='outlayer_b')
        y=tf.matmul(x3, W) + b
    with tf.name_scope("hard_output") as scope:
        hard_output= tf.nn.softmax(y)
    with tf.name_scope("soft_output") as scope:
        soft_output= tf.nn.softmax(y/T)
    with tf.name_scope("soft_target") as scope:
        soft_target= tf.nn.softmax(s_/T)
    #with tf.name_scope("L2"):
        #L2=tf.nn.l2_loss(W1)+tf.nn.l2_loss(W2)+tf.nn.l2_loss(W3)+tf.nn.l2_loss(W4)+tf.nn.l2_loss(W5)+tf.nn.l2_loss(W)
        #tf.histogram_summary('L2', L2)
    with tf.name_scope("hard_loss") as scope:
        hardloss= -tf.reduce_sum(hard_target*tf.log(tf.clip_by_value(hard_output,1e-25,1.0)))
        h_loss=tf.scalar_summary('hard_loss', hardloss)
    with tf.name_scope("soft_loss") as scope:
        softloss=-tf.reduce_sum(soft_target*tf.log(tf.clip_by_value(soft_output,1e-25,1.0)))
        s_loss=tf.scalar_summary('soft_loss', softloss)
    with tf.name_scope("weighted_losses") as scope:
        allloss=hardloss * (1-L) + softloss*L*T*T
        a_loss=tf.scalar_summary('total_loss', allloss)
    with tf.name_scope("Accuracy") as scope:
        accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(hard_output,1), tf.argmax(hard_target,1)), tf.float32))
        accuracysum=tf.scalar_summary('accuracy', accuracy)
    #learning_rate = tf.train.exponential_decay(learningrate, global_step,913342*2/batch_size, 0.9, staircase=0)
    #tf.scalar_summary('learning_rate', learning_rate)
    with tf.name_scope("trainer") as scope:
        train_step = tf.train.AdamOptimizer(learning_rate=learningrate).minimize(allloss,global_step=global_step)
        #train_step = tf.train.RMSPropOptimizer(learningrate,decay=0.9, momentum=0.9,epsilon=1e-9).minimize(allloss,global_step=global_step)

    #shuffle
    
    train_writer = tf.train.SummaryWriter("train",sess.graph)
    test_writer = tf.train.SummaryWriter("test")
    init = tf.initialize_all_variables()
    merged = tf.merge_all_summaries()
    
    if readweights==0:
        sess.run(init)
        saver = tf.train.Saver()
    else:
        sess.run(init)
        saver = tf.train.Saver()
        fname=PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.ckpt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
        saver.restore(sess, fname)


    print 'start training...'
    batch_idx = 0
    epoch = 0
    p=1 #patience
    print('start train')
    for i in range(N_EPOCHS):
        b=0
        order=np.random.permutation(2)+1
        batch_x,batch_y=shuffle2lists(order[0])
        print "1st train set:"
        print(batch_x.shape)
        print(batch_y.shape)
        while b <len(batch_x):
            summary, _ = sess.run([merged, train_step],feed_dict={x:batch_x[b:b+B],hard_target:batch_y[b*TIMESTEP:(b+B)*TIMESTEP],kp:drp,T:Tem,L:lamda})
            train_writer.add_summary(summary, global_step.eval())
            b=b+B
        b=0
        batch_x,batch_y=shuffle2lists(order[1])
        print "2nd train set:"
        print(batch_x.shape)
        print(batch_y.shape)
        while b <len(batch_x):
            summary, _ = sess.run([merged, train_step],feed_dict={x:batch_x[b:b+B],hard_target:batch_y[b*TIMESTEP:(b+B)*TIMESTEP],kp:drp,T:Tem,L:lamda})
            train_writer.add_summary(summary, global_step.eval())
            b=b+B
    return 0


def train(ilr=1e-2,elr=1e-6,batch_size=64,N_HIDDEN=2048,LN=4,times=0,drp=0.1,patience=3,lamda=0.2,Tem=1.0):
    lossvali=100000000
    softvali=100000000
    allvali=100000000
    accvali=0
    rate=ilr
    if times==0:
        f=open(PATH+('/distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.txt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda)),'w')
        f.write('learningrate starts from %s\n' %rate)
        f.write('layers:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,drp,batch_size))
        f.close()
    print 'learningrate starts from %s' %rate
    while rate>elr:
        if times==0:
            readweights=0
        else :
            readweights=True
        blstm(rate,lossvali,accvali,softvali,allvali,batch_size,N_HIDDEN,LN,drp,readweights,patience=patience,lamda=lamda,Tem=Tem)
        rate=rate*0.1
        print 'learningrate:%s'%rate
        times+=1
train(ilr=1e-4,elr=1e-7,batch_size=256,N_HIDDEN=512,LN=4,times=0,drp=0.7,patience=20,lamda=0.5,Tem=10.0)
