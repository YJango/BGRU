import theano
import theano.tensor as T
import lasagne
import numpy as np
from keras.utils import np_utils
from keras.objectives import categorical_crossentropy
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
from HTKRW import openx
import struct

NUM_STATES=120
window_size=17
N_EPOCHS = 100
SET=int(sys.argv[1])
PATH="/home/jango/distillation"
DIC="/home/jango/distillation/shared_babel/phone.dic"
LM="/home/jango/distillation/shared_babel/pdnet"
HLIST="/home/jango/distillation/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"
JULIUS='julius-4.3.1'
HRESULTS='HResults'
np.random.seed(55)
MODEL='teacher'
def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def shufflelists(X_t,y_t):
    ri=np.random.permutation(len(X_t))
    X=X_t[ri]
    y=y_t[ri]
    return X,y

#**********************************
#       HTK function              *
#**********************************
def write_htk(features,outputFileName,fs=100,dt=9):
    sampPeriod = 1./fs
    pk =dt & 0x3f
    features=np.atleast_2d(features)
    if pk==0:
        features =features.reshape(-1,1)
    with open(outputFileName,'wb') as fh:
        fh.write(struct.pack(">IIHH",len(features),sampPeriod*1e7,features.shape[1]*4,dt))
        features=features.astype(">f")
        features.tofile(fh)
#**********************************
#       julius recognizer         *
#**********************************
def RecogWithStateProbs(typ,s=2,pl=2):
    MODEL=PATH+"/%s/HMM%s/hmmdefs" %(typ,SET)
    testlist=PATH+"/%s/feature/list%s/testdnn.list" %(typ,SET)

    cmd='echo | %s -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s %s' %(JULIUS,testlist, HLIST, MODEL, LM, DIC, OPT, s, pl,"-input outprob")
    result=check_output(cmd,shell=1).split("\n")
    #print cmd
    #print cmd
    #print result
    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/LSTMRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd=HRESULTS+' -A -z ::: -I '+PATH+'/shared_babel/mlf%s/alignedtest.mlf -e ::: s_s -e ::: s_e %s %s/%s/LSTMRec/rec.mlf' %(SET,HLIST,PATH,typ)
    #print cmd
    acc=check_output(cmd,shell=1)
    #print acc
    #print acc
    PER=100-float(acc.split("\n")[-3].split(" ")[2].split("=")[1])
    #print PER
    return PER
#**********************************
#   get results                   *
#**********************************
def GetStateProbs(typ,get_out):
    #load state priors
    priors=dict([line.split() for line in open(PATH+"/%s/StatPrior%s_train" %(typ,SET)).readlines()])
    #change datatype
    priors=dict([(int(a),float(b)) for a, b in priors.items()])
    #turn into 1D vector in order
    priors=np.array([priors[i] for i in range(len(priors))])
    #get file list
    fnames=open(PATH+"/%s/feature/list%s/testmfc.list" %(typ,SET)).readlines()
    #
    #loop all files in filelist
    for name in fnames:
        #print name[:-1]
        fmfc=openx(name[:-1],'rb',veclen=87)
        data=fmfc.getall()
        vecs=MakeWindows(data,17).astype('float32')
        #make windows
        #get result from DNN
        probs=get_out(vecs)

        #turn into likelihoods
        log_liks=np.log10(probs/priors)
        #print log_liks.shape
        prob_path=PATH+"/%s/StatePro%s/" %(typ,SET)+name.split("/")[-1][:-4]+"llk"
        #print prob_path
        write_htk(log_liks,prob_path)
    PER=RecogWithStateProbs(typ,2,2)
    return PER

#-------------------------------------------------load data 
skip=window_size / 2
#train data
#inputs =np.load(PATH+"/teacher/DnnFile%s/stu_train.npy" %SET)
#make window
#X_TRAIN=MakeWindows(inputs,window_size).astype('float32')

#load train targets
#targets = np.load(PATH+"/teacher/DnnFile%s/stu_train_target.npy" %SET)
#Y_train=np_utils.to_categorical(targets,NUM_STATES)
#Y_TRAIN=Y_train[skip:-skip].astype('int16')
#------------------------------------------------------------
#validation data
#inputs =np.load(PATH+"/teacher/DnnFile%s/stu_validation.npy" %SET)
#make window
#X_VALI=MakeWindows(inputs,window_size).astype('float32')

#load train targets
#targets = np.load(PATH+"/teacher/DnnFile%s/stu_validation_target.npy" %SET)
#Y_validation=np_utils.to_categorical(targets,NUM_STATES)
#Y_VALI=Y_validation[skip:-skip].astype('int16')

#validation data
inputs =np.load(PATH+"/teacher/LSTMFile%s/tea_validation_lstm.npy" %SET)
targets = np.load(PATH+"/teacher/LSTMFile%s/tea_validation_target_lstm.npy" %SET)
X_VALI=[]
Y_VALI=[]
for x,y in zip(inputs,targets):
    X_VALI.append(MakeWindows(x,window_size).astype('float32'))
    Y_VALI.append(np_utils.to_categorical(y,NUM_STATES)[skip:-skip].astype('int16'))
X_VALI=np.vstack(X_VALI)
Y_VALI=np.vstack(Y_VALI)
print "validation_set:"
print X_VALI.shape
print Y_VALI.shape



def display(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
        sys.stdout.write('Epoch:%2.2s(%4.4s) | Train acc:%6.6s loss:%6.6s | Best acc:%6.6s loss:%6.6s | Cur acc:%6.6s loss:%6.6s | PER:%6.6s\r' %(times,round((float(b)/n_samples)*100,1),round(t_acc,4),round(t_loss,4),round(accvali,4),round(lossvali,4),round(acc,4),round(loss,4),round(PER,4)))
        sys.stdout.flush()
#--------------------------------------------------------------------------------------
def writer(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
    f=open(fname[:-4]+'.txt','a')
    f.write('Epoch:%2.2s | Train acc:%6.6s loss:%6.6s | Best acc:%6.6s loss:%6.6s | Cur acc:%6.6s loss:%6.6s | PER:%6.6s\n' %(times,round(t_acc,4),round(t_loss,4),round(accvali,4),round(lossvali,4),round(acc,4),round(loss,4),round(PER,4)))
    f.close()

def dnn(learningrate,lossvali,accvali,batch_size=32,N_HIDDEN=2048,LN=4,drp=0.2,readweights=False,patience=5):
    #variable holders
    hard_targets = T.imatrix('hard_target')

    #network

    l_in = lasagne.layers.InputLayer(shape=(None, X_VALI.shape[1]))
    #
    l_hidden = lasagne.layers.DenseLayer(
        l_in,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d=lasagne.layers.dropout(l_hidden,drp)
    l_hidden2 = lasagne.layers.DenseLayer(
        d,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d2=lasagne.layers.dropout(l_hidden2,drp)
    l_hidden3 = lasagne.layers.DenseLayer(
        d2,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d3=lasagne.layers.dropout(l_hidden3,drp)
    l_hidden4 = lasagne.layers.DenseLayer(
        d3,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d4=lasagne.layers.dropout(l_hidden4,drp)
    l_hidden5 = lasagne.layers.DenseLayer(
        d4,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d5=lasagne.layers.dropout(l_hidden5,drp)
    l_hidden6 = lasagne.layers.DenseLayer(
        d5,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d6=lasagne.layers.dropout(l_hidden6,drp)
    if LN==3:
        go_in=d3
    elif LN==4:
        go_in=d4
    elif LN==5:
        go_in=d5
    elif LN==6:
        go_in=d6
    else:
        print 'wrong layers number'
    l_out = lasagne.layers.DenseLayer(
        go_in, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.softmax)
    

    #soft for train and eval

    hard_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=False), hard_targets))
    hard_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=True), hard_targets))
    
    loss_eval = hard_loss_eval

    loss_train = hard_loss_train

    all_params = lasagne.layers.get_all_params(l_out)

    #updates = lasagne.updates.nesterov_momentum(loss_train, all_params,learning_rate=learningrate)
    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=learningrate)
    #updates = lasagne.updates.rmsprop(loss_train, all_params,learning_rate=learningrate)
    get_acc = theano.function([l_in.input_var,hard_targets], T.mean(lasagne.objectives.categorical_accuracy(lasagne.layers.get_output(l_out, deterministic=True), hard_targets)))
    
    #output of network
    #get_train=theano.function([l_in.input_var],lasagne.layers.get_output(l_out, deterministic=True))
    #acc for hard

    #get two losses
    get_loss = theano.function([l_in.input_var,hard_targets], hard_loss_eval)

    get_out=theano.function([l_in.input_var],lasagne.layers.get_output(l_out, deterministic=True))
    train = theano.function([l_in.input_var, hard_targets], [hard_loss_eval,T.mean(lasagne.objectives.categorical_accuracy(lasagne.layers.get_output(l_out, deterministic=True), hard_targets))], updates=updates)

    if readweights==True:
        fname=PATH+('/teacher/DnnWeight%s/tea' %SET+'_%dL%d_drp%s_batch%d.npy' %(LN,N_HIDDEN,drp,batch_size))
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)

    batch_idx = 0
    stargets=[]
    epoch=0
    while epoch < N_EPOCHS:
        stargets.append(get_out(X_VALI[batch_idx:batch_idx + batch_size]))
        batch_idx += batch_size
        if batch_idx >= X_VALI.shape[0]:    
            haha=np.vstack(stargets)
            print haha.shape
            np.save('/home/jango/distillation/distrain/soft_targets/%s/soft_vali.npy' %SET,haha)
            exit()

            
def train(ilr=1e-4,elr=1e-6,batch_size=64,N_HIDDEN=2048,LN=4,lamda=0.2,times=0,Tem=1.0,drp=0.1,patience=3):
    lossvali=100
    accvali=0
    rate=ilr
    while rate>elr:
        lossvali,accvali=dnn(rate,lossvali,accvali,batch_size,N_HIDDEN,LN,drp,readweights=True,patience=patience)
        rate=rate*0.1


train(ilr=1e-4,elr=1e-6,batch_size=256,N_HIDDEN=2048,LN=4,drp=0.4,patience=6)
