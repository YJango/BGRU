import numpy as np
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
#from HTKRW import openx
import theano
import theano.tensor as T
import lasagne
import struct,math
#**********************************
#       paramters                 *
#**********************************
PATH="/hi-home/jyu/distillation"
DIC=PATH+"/shared_babel/phone.dic"
LM=PATH+"/shared_babel/pdnet"
HLIST=PATH+"/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"
JULIUS='julius'
HRESULTS='HResults'
NUM_STATES=120
N_EPOCHS = 100
TIMESTEP=41
_EPSILON=1e-15
np.random.seed(55)
MODEL='student'
MODEL2="teacher"
PS=3e-4
NET='IBO'
from lasagne.regularization import l2
SET=int(sys.argv[1])
if MODEL=="teacher":
    N_INPUT=87
else:
    N_INPUT=39
#**********************************
#       HTK function              *
#**********************************
def write_htk(features,outputFileName,fs=100,dt=9):
    sampPeriod = 1./fs
    pk =dt & 0x3f
    features=np.atleast_2d(features)
    if pk==0:
        features =features.reshape(-1,1)
    with open(outputFileName,'wb') as fh:
        #print(len(features),sampPeriod*1e7,features.shape[1]*4,dt)
        fh.write(struct.pack(">IIHH",len(features),int(sampPeriod*1e7),features.shape[1]*4,dt))
        features=features.astype(">f")
        features.tofile(fh)

def read_htk(inputFileNmae, framePerSecond=100):
    kinds=['WAVEFORM','LPC','LPREFC','LPCEPSTRA','LPDELCEP','IREFC','MFCC','FBANK','MELSPEC','USER','DISCRETE','PLP','ANON','???']
    with open(inputFileNmae, 'rb') as fid:
        nf=struct.unpack(">l",fid.read(4))[0]
        fp=struct.unpack(">l",fid.read(4))[0]*-1e-7
        by=struct.unpack(">h",fid.read(2))[0]
        tc=struct.unpack(">h",fid.read(2))[0]
        tc=tc+65536*(tc<0)
        cc='ENDACZK0VT'
        nhb=len(cc)
        ndt=6
        hb=list(int(math.floor(tc * 2 ** x)) for x in range(- (ndt+nhb),-ndt+1))
        dt=tc-hb[-1] *2 **ndt
        if any([dt == x for x in [0,5,10]]):
            aise('NOt!')
        data=np.asarray(struct.unpack(">"+"f"*int(by/4)*nf,fid.read(by*nf)))
        d=data.reshape(nf,int(by/4))
    t=kinds[min(dt,len(kinds)-1)]
    return (d,fp,dt,tc,t)
#**********************************
#       julius recognizer         *
#**********************************
def RecogWithStateProbs(typ,s=2,pl=2):
    MODEL=PATH+"/teacher/HMM%s/hmmdefs" %SET
    testlist=PATH+"/%s/feature/list%s/testdnn.list" %(typ,SET)

    cmd='echo | %s -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s %s' %(JULIUS,testlist, HLIST, MODEL, LM, DIC, OPT, s, pl,"-input outprob")
    #print(cmd)
    result=str(check_output(cmd,shell=1)).split("\\n")
    #print cmd
    
    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/LSTMRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd=HRESULTS+' -A -z ::: -I '+PATH+'/shared_babel/mlf%s/alignedtest.mlf -e ::: s_s -e ::: s_e %s %s/%s/LSTMRec/rec.mlf' %(SET,HLIST,PATH,typ)
    acc=str(check_output(cmd,shell=1))
    #print(acc)
    PER=100-float(acc.split("\\n")[-3].split(" ")[2].split("=")[1])
    #print("%s    s: %s, p: %s, PER: %s" %(typ,s,pl,PER))
    return PER
#**********************************
#       data processing function  *
#**********************************
def per_sentence(seq_X,seq_Y,time_step=TIMESTEP):
    """lstm data generator 
    Args:
      seq_X: a sequence of vectors for one sentence (len, input_Dim)
      seq_Y: a sequence of vectors for one sentence (len, output_Dim)
      time_step: the length of history
    Returns:
      lstm_X: (n_size, timestep, input_Dim)
      lstm_Y: (n_size, )
      mask: for implementing variable length lstm
    note:
      
    """
    N_input=seq_X.shape[1]
    sen_len=len(seq_X)
    front=int(time_step/2)
    seq_X=np.vstack((np.zeros((front,N_input)),seq_X,np.zeros((front,N_input))))
    seq_M=np.hstack((np.zeros(front),np.ones(sen_len),np.zeros(front)))

    lstm_X = np.zeros((sen_len, time_step, N_input))
    lstm_M = np.ones((sen_len, time_step))

    for i in range(0,sen_len):
        lstm_X[i]=seq_X[i:time_step+i]           
        lstm_M[i]=seq_M[i:time_step+i]  
    return lstm_X.astype("float32"),seq_Y.astype("int16"),lstm_M.astype("int16")
def per_sentence2_noY(seq_X,time_step=TIMESTEP):
    """lstm data generator without Y
    Args:
      seq_X: a sequence of vectors for one sentence (len, input_Dim)
      time_step: the length of history
    Returns:
      lstm_X: (n_size, timestep, input_Dim)
      mask: for implementing variable length lstm
    note:
      
    """
    N_input=seq_X.shape[1]
    sen_len=len(seq_X)
    front=int(time_step/2)
    seq_X=np.vstack((np.zeros((front,N_input)),seq_X,np.zeros((front,N_input))))
    seq_M=np.hstack((np.zeros(front),np.ones(sen_len),np.zeros(front)))

    lstm_X = np.zeros((sen_len, time_step, N_input))
    lstm_M = np.ones((sen_len, time_step))

    for i in range(0,sen_len):
        lstm_X[i]=seq_X[i:time_step+i]           
        lstm_M[i]=seq_M[i:time_step+i]  
    return lstm_X.astype("float32"),lstm_M.astype("int16")
#--------------------------------------------------------------------------------------
def total_sentences(X,Y,time_step=TIMESTEP):
    """lstm data generator 
    return:
      total sentences tensors
    """
    XX=list()
    YY=list()
    MM=list()
    for x,y in zip(X,Y):
        xx,yy,mm=per_sentence(x,y,time_step)
        XX.append(xx)
        YY.append(yy)
        MM.append(mm)
    return np.concatenate(XX).astype("float32"),lasagne.utils.one_hot(np.concatenate(YY)).eval().astype("int16"),np.concatenate(MM).astype("int16")
#**********************************
#       read data                 *
#**********************************
X_TRAIN=np.load(PATH+"/"+MODEL+"/LSTMFile%s/%s_train_lstm.npy" %(SET,MODEL[:3]),encoding='latin1')
Y_TRAIN=np.load(PATH+"/"+MODEL2+"/LSTMFile%s/%s_train_target_lstm.npy" %(SET,MODEL2[:3]),encoding='latin1')
X_TRAIN,Y_TRAIN,M_TRAIN=total_sentences(X_TRAIN,Y_TRAIN,time_step=TIMESTEP)


#read validation data
X_VALI=X_TRAIN[:int(len(M_TRAIN)/10)]
Y_VALI=Y_TRAIN[:int(len(M_TRAIN)/10)]
M_VALI=M_TRAIN[:int(len(M_TRAIN)/10)]
X_TRAIN=X_TRAIN[int(len(M_TRAIN)/10):]
Y_TRAIN=Y_TRAIN[int(len(M_TRAIN)/10):]
M_TRAIN=M_TRAIN[int(len(M_TRAIN)/10):]
SOFT_TRAIN=np.load(PATH+"/distrain/soft_targets/R%s/soft_train.npy" %SET).astype('float32')
SOFT_VALI=np.load(PATH+"/distrain/soft_targets/R%s/soft_vali.npy" %SET).astype('float32')
print('\ntrain data')
print(X_TRAIN.shape,Y_TRAIN.shape,M_TRAIN.shape,SOFT_TRAIN.shape)
print('vali data')
print(X_VALI.shape,Y_VALI.shape,M_VALI.shape,SOFT_VALI.shape)




#**********************************
#       evaluation functions      *
#**********************************
def get_acc_loss(get_out):
    real=T.matrix('real')
    pred=T.matrix('prediction')
    pred=T.clip(pred, _EPSILON, 1.0 - _EPSILON)
    vali_acc = theano.function([pred,real], T.mean(lasagne.objectives.categorical_accuracy(pred, real)))
    vali_loss = theano.function([pred,real], T.mean(lasagne.objectives.categorical_crossentropy(pred, real)))
    P=all_predictions(get_out)
    return vali_acc(P,Y_VALI),vali_loss(P,Y_VALI)
#--------------------------------------------------------------------------------------
def all_predictions(get_out,batch=32):
    all_pred=list()
    i=0
    while True:
        pred=get_out(X_VALI[i:i+batch],M_VALI[i:i+batch])
        i=i+batch
        all_pred.append(pred)
        if i >= X_VALI.shape[0]:
            return np.concatenate(all_pred)
#--------------------------------------------------------------------------------------
def display(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
        #print(type(times),type((float(b)/n_samples)*100),type(t_acc),type(t_loss),type(accvali),type(lossvali),type(acc),type(loss),type(PER))
        sys.stdout.write('Epoch:%2.2s(%4.4s) | Train acc:%5.5s loss:%5.5s | Best acc:%5.5s loss:%5.5s | Cur acc:%5.5s loss:%5.5s | PER:%5.5s\r' %(times,round((float(b)/n_samples)*100,1),round(float(t_acc),3),round(float(t_loss),3),round(float(accvali),3),round(float(lossvali),3),round(float(acc),3),round(float(loss),3),round(float(PER),3)))
        sys.stdout.flush()
#--------------------------------------------------------------------------------------
def writer(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
    f=open(fname[:-4]+'.txt','a')
    f.write('Epoch:%2.2s | Train acc:%5.5s loss:%5.5s | Best acc:%5.5s loss:%5.5s | Cur acc:%5.5s loss:%5.5s | PER:%5.5s\n' %(times,round(float(t_acc),3),round(float(t_loss),3),round(float(accvali),3),round(float(lossvali),3),round(float(acc),3),round(float(loss),3),round(float(PER),3)))
    f.close()
def prediction(X,get_out,batch=32):
    X,M=per_sentence2_noY(X,time_step=TIMESTEP)
    all_pred=list()
    i=0
    while True:
        pred=get_out(X[i:i+batch],M[i:i+batch])
        i=i+batch
        all_pred.append(pred)
        if i >= X.shape[0]:
            return np.concatenate(all_pred)
#**********************************
#   get results                   *
#**********************************
def GetStateProbs(typ,n_hidden, n_cell, net, drp, B,get_out):
    #load state priors
    priors=dict([line.split() for line in open(PATH+"/teacher/StatPrior%s_train" %SET).readlines()])
    #change datatype
    priors=dict([(int(a),float(b)) for a, b in priors.items()])
    #turn into 1D vector in order
    priors=np.array([priors[i] for i in range(len(priors))])
    #get file list
    fnames=open(PATH+"/%s/feature/list%s/testmfc.list" %(typ,SET)).readlines()
    #
    #loop all files in filelist
    for name in fnames:
        #print name[:-1]
        data=read_htk(name[:-1])[0]
        #make windows
        X=data.astype('float32')
        #get result from DNN
        probs=prediction(X,get_out)
        #turn into likelihoods
        log_liks=np.log10(probs/priors)
        #print log_liks.shape
        prob_path=PATH+"/%s/StatePro%s/" %(typ,SET)+name.split("/")[-1][:-4]+"llk"
        #print prob_path
        write_htk(log_liks,prob_path)
    PER=RecogWithStateProbs(typ,3,2)
    return PER
#**********************************
#   network builder               *
#**********************************
def Dense(l_in, n_hidden, in_reshape, out_reshape, drp, init_b=0.001, timestep=TIMESTEP,n_features=N_INPUT):
    """Dense layer creater
    Args:
      l_in: incoming layer
      n_hidden: hidden layer nodes
      in_reshape: whether to reshape for FF
      in_reshape: whether to reshape for LSTM
      drp: drop out probability
      init_b: init bias for FF
      timestep: length of history to look
      n_features: input vector dimenstion
    Return:
      instance of lasagne layer
    """
    #reshape for feedforward
    if in_reshape == True:
        l_in = lasagne.layers.ReshapeLayer(l_in, (-1, n_features))
        print('Reshape for FF')
    #build dense layer
    l_in = lasagne.layers.DenseLayer(
        l_in,
        n_hidden, 
        b=lasagne.init.Constant(init_b),
        nonlinearity=lasagne.nonlinearities.rectify)
    print('Add Dense')
    print('Add Dropout')
    #reshape for blstm
    if out_reshape == True:
        l_in = lasagne.layers.ReshapeLayer(l_in, (-1,timestep, n_hidden))
        print('Reshape for BLSTM')
    #add dropout layer
    layer=lasagne.layers.dropout(l_in,drp)
    return layer,lasagne.regularization.regularize_layer_params([l_in], l2)
#--------------------------------------------------------------------------------------
def BLSTM(l_in, l_mask, n_cell, drp):
    """BLSTM layer creater
    Args:
      l_in: incoming layer
      l_mask: lasagne mask layer
      n_cell: size of lstm cell
      last: whether to only return final sequential output
      drp: drop out probability
      f_bias: init bias for forget gate
    Return:
      instance of lasagne layer
    """
    #parameters of LSTM
    gate_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(0.))
    forget_gate = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(1.0))
    cell_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        W_cell=None, b=lasagne.init.Constant(0.),
        nonlinearity=lasagne.nonlinearities.tanh)
    #BLSTM
    l_lstm = lasagne.layers.recurrent.LSTMLayer(
        l_in, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=1, grad_clipping=100., backwards=False)
    l_lstm_b = lasagne.layers.recurrent.LSTMLayer(
        l_in, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=1, grad_clipping=100., backwards=True)
    l_in = lasagne.layers.ElemwiseSumLayer([l_lstm, l_lstm_b])
    l_in=lasagne.layers.dropout(l_in,drp)
    l_in = lasagne.layers.ReshapeLayer(l_in, (-1, n_cell))
    return l_in
def BLSTM2(l_in, l_mask, n_cell, last, drp, f_bias=1.0):
    """BLSTM layer creater
    Args:
      l_in: incoming layer
      l_mask: lasagne mask layer
      n_cell: size of lstm cell
      last: whether to only return final sequential output
      drp: drop out probability
      f_bias: init bias for forget gate
    Return:
      instance of lasagne layer
    """
    #parameters of LSTM
    gate_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(0.))
    forget_gate = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(1.0))
    cell_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        W_cell=None, b=lasagne.init.Constant(0.),
        nonlinearity=lasagne.nonlinearities.tanh)
    #BLSTM
    l_lstm = lasagne.layers.recurrent.LSTMLayer(
        l_in, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=True, grad_clipping=100., backwards=False)
    l_lstm_b = lasagne.layers.recurrent.LSTMLayer(
        l_in, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=True, grad_clipping=100., backwards=True)
    l_lstm2 = lasagne.layers.recurrent.LSTMLayer(
        l_lstm, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=True, grad_clipping=100., backwards=False, only_return_final=1)
    l_lstm_b2 = lasagne.layers.recurrent.LSTMLayer(
        l_lstm_b, n_cell,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=forget_gate,
        learn_init=True, grad_clipping=100., backwards=True, only_return_final=1)

    l_in = lasagne.layers.ConcatLayer([l_lstm2, l_lstm_b2])
    print('Add deep BLSTMs (2 layers)')
    layer=lasagne.layers.dropout(l_in,drp)
    print('Add Dropout')
    return layer
#--------------------------------------------------------------------------------------
def Network(l_in, l_mask, n_out, n_hidden, n_cell, net, drp, n_input=87):
    """network builder
    Args:
      l_in: lasagne input layer
      l_mask: lasagne mask layer
      n_class: number of labels
      n_hidden: number of hidden layer nodes
      n_cell: size of lstm cell
      net: a string denoting the type of network, starting with 'I', ending with 'O'.
          I: input layer
          F: feedforward layer
          B: bgru layer
          O: output layer
          note: the net can contain no dense layer, but must contain at least one blstm
      drp: drop out probability
      n_input: input vector dimenstion
    Return:
      instance of lasagne layer
    """
    print('Add Inputlayer')
    #hidden layers
    n_batch, n_time_steps, n_features = l_in.input_var.shape
    Pena=0
    for i,l in enumerate(net):
        #add dense net
        if l == 'F':
            #if it's the first dense_layer, reshape will be performed to use feedforward
            if i == 1:
                in_reshape=True
            else:
                in_reshape=False
            #if it's the last dense_layer, reshape will be performed to use blstm
            if net[i+1] == 'B':
                out_reshape=True
            else:
                out_reshape=False  
            if net[i+1] =="O":
                n_hid=120
                print("120")
            else:
                n_hid=n_hidden
            l_in,pp=Dense(l_in, n_hid, in_reshape, out_reshape, drp, init_b=0.001)
            Pena+=pp
        #add blstm net
        elif l == 'B':
            l_in=BLSTM(l_in, l_mask, n_cell, drp)
    
    #l_in = lasagne.layers.ReshapeLayer(l_in, (-1, n_cell))
    #output layer  
    l_in = lasagne.layers.DenseLayer(l_in, num_units=n_out, nonlinearity=lasagne.nonlinearities.linear)
    l_in = lasagne.layers.ReshapeLayer(l_in, (n_batch, n_time_steps, n_out))
    print('Add output softmax')
    return l_in,Pena
#**********************************
#   train functions               *
#**********************************
def shuffle3lists(x,y,s,m):
    ri=np.random.permutation(len(x))
    return x[ri],y[ri],s[ri],m[ri]
#--------------------------------------------------------------------------------------
def trainer(lossvali,accvali, n_hidden, n_cell, net, drp, n_input=N_INPUT, lr=1e-4,times=0,B=128,patience=3,n_class=NUM_STATES,Tem=1.0,lamda=0.6):
    #placeholders
    
    l_in = lasagne.layers.InputLayer(shape=(None, None, n_input))
    l_mask = lasagne.layers.InputLayer(shape=(None, None))
    hard_targets = T.matrix('hard_target')
    soft_targets = T.matrix('soft_target')
    
    #build network and return output
    print('build network net: %s' %net)
    l_out,Pena=Network(l_in, l_mask, n_class, n_hidden, n_cell, net, drp, n_input=N_INPUT)
    #params
    all_params = lasagne.layers.get_all_params(l_out)
    #output with dropout for train
    l_out_train = lasagne.layers.get_output(l_out, deterministic=False)[:,int(TIMESTEP/2),:].reshape((-1,NUM_STATES))
    l_out_eval = lasagne.layers.get_output(l_out, deterministic=True)[:,int(TIMESTEP/2),:].reshape((-1,NUM_STATES))

    hard_softmax_train = T.exp(l_out_train)/T.sum(T.exp(l_out_train),axis=1, keepdims=True)
    hard_softmax_eval = T.exp(l_out_eval)/T.sum(T.exp(l_out_eval),axis=1, keepdims=True)

    hard_softmax_train=T.clip(hard_softmax_train, _EPSILON, 1.0 - _EPSILON)
    hard_softmax_eval=T.clip(hard_softmax_eval, _EPSILON, 1.0 - _EPSILON)

    soft_softmax_train = T.exp(l_out_train/Tem)/T.sum(T.exp(l_out_train/Tem),axis=1, keepdims=True)
    soft_softmax_eval = T.exp(l_out_eval/Tem)/T.sum(T.exp(l_out_eval/Tem),axis=1, keepdims=True)
    soft_softmax_train=T.clip(soft_softmax_train, _EPSILON, 1.0 - _EPSILON)
    soft_softmax_eval=T.clip(soft_softmax_eval, _EPSILON, 1.0 - _EPSILON)

    soften = T.exp(soft_targets/Tem)/T.sum(T.exp(soft_targets/Tem),axis=1, keepdims=True)

    hard_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(hard_softmax_train, hard_targets))*(1-lamda)
    hard_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(hard_softmax_eval, hard_targets))*(1-lamda)

    soft_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(soft_softmax_train,soften))*lamda*Tem*Tem
    soft_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(soft_softmax_eval,soften))*lamda*Tem*Tem

    loss_train = hard_loss_train+soft_loss_train+Pena*PS
    loss_eval = hard_loss_eval+soft_loss_eval
     
    #update
    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=lr)
    #train
    #train = theano.function([l_in.input_var, hard_targets, soft_targets, l_mask.input_var], loss_eval, updates=updates)
    #get output of network
    get_out=theano.function([l_in.input_var, l_mask.input_var],l_out_eval)
    #train of network with acc and loss

    acc_eval = T.mean(lasagne.objectives.categorical_accuracy(hard_softmax_eval, hard_targets))


    train_acc_loss = theano.function([l_in.input_var, hard_targets, soft_targets, l_mask.input_var], [hard_loss_eval,acc_eval], updates=updates)
    #restore params
    fname=PATH+"/"+MODEL+('/LSTMWeight%s/%s_%s_%d_%d_drp%s_batch%d_timestep%d.npy' %(SET,MODEL[:3],net,n_hidden,n_cell,drp,B,TIMESTEP))
    if times>=2:
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)
        print('weights loaded')
    p=1 #init patience
    p_local=1 #init patience
    acc,loss=get_acc_loss(get_out)
    PER=0#GetStateProbs(MODEL,n_hidden, n_cell, net, drp, B, get_out)
    if loss<lossvali:
        lossvali=loss
        accvali=acc
    print('\ntraining...')
    global X_TRAIN,Y_TRAIN,SOFT_TRAIN,M_TRAIN
    n_samples=len(X_TRAIN)
    while times <= N_EPOCHS:
        b=1
        X_TRAIN,Y_TRAIN,SOFT_TRAIN,M_TRAIN=shuffle3lists(X_TRAIN,Y_TRAIN,SOFT_TRAIN,M_TRAIN)
        t_l=1e-25
        t_a=1e-25
        while b < n_samples:
            t_loss,t_acc=train_acc_loss(X_TRAIN[b:b+B],Y_TRAIN[b:b+B],SOFT_TRAIN[b:b+B],M_TRAIN[b:b+B])
            t_l+=float(t_loss)*len(M_TRAIN[b:b+B])
            t_a+=float(t_acc)*len(M_TRAIN[b:b+B])
            t_loss=t_l/b
            t_acc=t_a/b
            display(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc)
            b=b+B
        acc,loss=get_acc_loss(get_out)
        PER=GetStateProbs(MODEL,n_hidden, n_cell, net, drp, B, get_out)
        if lossvali>=loss:
            weights = lasagne.layers.get_all_param_values(l_out)
            np.save(fname,weights)
            lossvali=loss
            accvali=acc
            writer(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc)
            p=1
        else:
            p+=1
            writer(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc)
            if p>patience:
                print('\n')
                return lossvali,accvali,times-patience+1
        times+=1
    print('\n')
    return lossvali,accvali,N_EPOCHS
#--------------------------------------------------------------------------------------
def controler(ilr=1e-4,elr=1e-6,batch_size=128,n_hidden=1024,n_cell=256,times=1,drp=0.2,patience=3,p_eval=1,net=NET):
    lossvali=100
    accvali=0
    rate=ilr
    fname=PATH+"/"+MODEL+('/LSTMWeight%s/%s_%s_%d_%d_drp%s_batch%d_timestep%d.txt' %(SET,MODEL[:3],net,n_hidden,n_cell,drp,batch_size,TIMESTEP))
    f=open(fname,'w')
    f.write('ff_nodes:%d,lstm_nodes:%d, dropout:%s, batch_size: %s, net: %s, timestep: %d\n---------------------------------\n' %(n_hidden,n_cell,drp,batch_size,net, TIMESTEP))
    f.close()
    LR=[1e-4,3e-5,7e-6,1e-6]
    for LL in LR:
        rate=LL
        #print('learningrate:%s'%rate)
        if times!=N_EPOCHS:
            f=open(fname,'a')
            f.write('learningrate starts from %s\n' %rate)
            f.close()
            print('\nlearningrate:%s\ndropout:%s\ncell_size:%s\nhidden_nodes:%s' %(rate,drp,n_cell,n_hidden))
            lossvali,accvali,times=trainer(lossvali, accvali, n_hidden, n_cell, net, drp,lr=rate,times=times,B=batch_size,patience=patience)
            rate=rate*0.1
        else:
            #f=open(fname,'a')
            #f.write('Epoch:%2.2s | Best acc:%5.5s loss:%5.5s\n' %(times,round(accvali,3),round(lossvali,3)))
            #f.close()
            return 
    #f=open(fname,'a')
    #f.write('Epoch:%2.2s | Best acc:%5.5s loss:%5.5s\n' %(times,round(accvali,3),round(lossvali,3)))
    #f.close()
"""
timestep 30,batch_size=128,n_hidden=2048,n_cell=1024
[0.1,0.2,0.3,0.4,0.5,0.6]---6
['IBO','IBBO','IFBO','IFBBO','IFBFO','IFFBFFO']---6
36 models

net:
I: input layer
F: feedforward layer
B: blstm layer
D: deep blstm layers (2)
O: output layer
note: the net can contain no dense layer, but must contain at least one blstm
"""


for n in ['IFFBFFO']:
    for d in [0.3]:
        controler(ilr=1e-4,elr=1e-6,batch_size=32,n_hidden=2048,n_cell=2048,drp=d,patience=1,net=n)
