import theano
import theano.tensor as T
import lasagne
import numpy as np
from keras.utils import np_utils
#****************************************************************************************
PATH="/home/jango/distillation"
MODEL='teacher'
TIMESTEP=20
NUM_STATES=120
N_EPOCHS = 50
np.random.seed(55)
_EPSILON=1e-15
if MODEL=="teacher":
    N_INPUT=87
else:
    N_INPUT=39
#****************************************************************************************
def categorical_crossentropy(output, target, from_logits=False):
    if from_logits:
        output = T.nnet.softmax(output)
    else:
        # scale preds so that the class probas of each sample sum to 1
        output /= output.sum(axis=-1, keepdims=True)
    # avoid numerical instability with _EPSILON clipping
    output = T.clip(output, _EPSILON, 1.0 - _EPSILON)
    return T.nnet.categorical_crossentropy(output, target)

def get_acc_loss(get_out):
    real=T.matrix('real')
    prediction=T.matrix('prediction')
    vali_acc = theano.function([prediction,real], T.mean(lasagne.objectives.categorical_accuracy(prediction, real)))
    vali_loss = theano.function([prediction,real], T.mean(categorical_crossentropy(prediction, real)))
    #read validation data
    X_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_lstm.npy" %MODEL[:3])
    Y_VALI=np.load(PATH+"/"+MODEL+"/LSTMFile/%s_validation_target.npy" %MODEL[:3])
    Y_VALI=np_utils.to_categorical(Y_VALI,NUM_STATES).astype('int16')
    P=all_predictions(X_VALI,get_out)
    return vali_acc(P,Y_VALI),vali_loss(P,Y_VALI)
    
def tensor3(X,timestep=TIMESTEP):
    N_input=X.shape[1]
    tensorX=np.zeros((len(X),timestep,N_input))
    tensorM=np.zeros((len(X),timestep))
    #append  timestep-1 zero_vectors at the begining
    #M=np.hstack((np.zeros((timestep-1,)),np.ones(len(X),)))
    #X=np.vstack((np.zeros((timestep-1,N_input)),X))
    for i in range(0,len(tensorM)):
        if i <timestep-1:
            tensorX[i]=np.vstack((X[:i+1],np.zeros((timestep-i-1,N_input))))
            tensorM[i]=np.hstack((np.ones(i+1),np.zeros(timestep-i-1)))
        else:
            tensorX[i]=X[i-timestep+1:i+1]
            tensorM[i]=np.ones(timestep)
    return tensorX.astype("float32"),tensorM.astype("int16")

def AIO(X,timestep=TIMESTEP):
    XX=list()
    MM=list()
    for x in X:
        xx,mm=tensor3(x,timestep)
        XX.append(xx)
        MM.append(mm)
    return np.concatenate(XX).astype("float32"),np.concatenate(MM).astype("int16")

def all_predictions(X,get_out,batch=256):
    allpy=list()
    batch_x,mask=AIO(X)
    i=0
    while 1:
        ss=get_out(batch_x[i:i+batch],mask[i:i+batch])
        i=i+batch
        allpy.append(ss)
        if i >= batch_x.shape[0]:
            return np.concatenate(allpy).astype("float32")
    

def shuffle2lists():
    X=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_X_train_lstm.npy" %(TIMESTEP,MODEL[:3]))
    Y=np.load(PATH+"/"+MODEL+"/LSTMFile/%dtimestep/%s_Y_train_lstm.npy" %(TIMESTEP,MODEL[:3]))
    ri=np.random.permutation(len(X))
    return X[ri],Y[ri]
#****************************************************************************************
def blstm(learningrate,lossvali,accvali,B=128,N_HIDDEN=2048,LSTM_HIDDEN=256,drp=0.2,readweights=False,patience=3):
    #variable holders
    hard_targets = T.matrix('hard_target')
    print "build model"
    #network
    #input layer
    l_in = lasagne.layers.InputLayer(shape=(None, None, N_INPUT))
    l_mask = lasagne.layers.InputLayer(shape=(None, None))
#--------------------------parameters of LSTM----------
    gate_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        b=lasagne.init.Constant(0.))
    cell_parameters = lasagne.layers.recurrent.Gate(
        W_in=lasagne.init.Orthogonal(), W_hid=lasagne.init.Orthogonal(),
        W_cell=None, b=lasagne.init.Constant(0.),
        nonlinearity=lasagne.nonlinearities.tanh)
#--------------------reshape--for Feedforward layer--------------------
    n_batch, n_time_steps, n_features = l_in.input_var.shape
    l_reshape0 = lasagne.layers.ReshapeLayer(l_in, (-1, N_INPUT))
#--------------------------Feedforward layer 1 ----------------------
    l_dense1 = lasagne.layers.DenseLayer(
        l_reshape0, N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),nonlinearity=lasagne.nonlinearities.rectify)
#--------------------------dropout 1 ----------------------
    d1=lasagne.layers.dropout(l_dense1,drp)
#--------------------------Feedforward layer 2 ----------------------
    l_dense2 = lasagne.layers.DenseLayer(
        d1, N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),nonlinearity=lasagne.nonlinearities.rectify)
#--------------------------dropout 2 ----------------------
    d2=lasagne.layers.dropout(l_dense2,drp)
#--------------------reshape--for BLSTM--------------------
    l_out0 = lasagne.layers.ReshapeLayer(d1, (-1,n_time_steps, N_HIDDEN))
#-------------------------BLSTM-------------------------
    l_lstm = lasagne.layers.recurrent.LSTMLayer(
        l_out0, LSTM_HIDDEN,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=False)
#----------------------
    l_lstm_back = lasagne.layers.recurrent.LSTMLayer(
        l_out0, LSTM_HIDDEN, ingate=gate_parameters,
        mask_input=l_mask, 
        forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=True)
    l_sum = lasagne.layers.ElemwiseSumLayer([l_lstm, l_lstm_back])
    dl1=lasagne.layers.dropout(l_sum,drp)
#--------------------------BLSTM2-------------------------
    l_lstm2 = lasagne.layers.recurrent.LSTMLayer(
        dl1, LSTM_HIDDEN,
        mask_input=l_mask,
        ingate=gate_parameters, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=False, only_return_final=True)
    l_lstm_back2 = lasagne.layers.recurrent.LSTMLayer(
        dl1, LSTM_HIDDEN, ingate=gate_parameters,
        mask_input=l_mask, forgetgate=gate_parameters,
        cell=cell_parameters, outgate=gate_parameters,
        learn_init=True, grad_clipping=100., backwards=True, only_return_final=True)
    l_sum2 = lasagne.layers.ConcatLayer([l_lstm2, l_lstm_back2])
    dl2=lasagne.layers.dropout(l_sum2,drp)
#-------------------------------Feedforward layer 3 --------------------
#    l_dense3 = lasagne.layers.DenseLayer(
#        dl2, N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),nonlinearity=lasagne.nonlinearities.rectify)
#    d4=lasagne.layers.dropout(l_dense3,drp)
#    l_dense4 = lasagne.layers.DenseLayer(
#        d4, N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),nonlinearity=lasagne.nonlinearities.rectify)
#    d5=lasagne.layers.dropout(l_dense4,drp)
#-------------------------------output layer --------------------
    l_out = lasagne.layers.DenseLayer(
        dl2, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.softmax)
#    l_out=lasagne.layers.ReshapeLayer(l_dense3, (-1,n_time_steps, NUM_STATES))
#----------------------------------------------------------------------------------------
    loss_train = T.mean(categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=False), hard_targets))
    loss_eval = T.mean(categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=True), hard_targets))

    all_params = lasagne.layers.get_all_params(l_out)
    #updates = lasagne.updates.nesterov_momentum(loss_train, all_params,learning_rate=learningrate)
    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=learningrate)
    #updates = lasagne.updates.rmsprop(loss_train, all_params,learning_rate=learningrate)

    train = theano.function([l_in.input_var, hard_targets, l_mask.input_var], loss_train, updates=updates)
    #output of network
    get_out=theano.function([l_in.input_var, l_mask.input_var],lasagne.layers.get_output(l_out, deterministic=True))

       
#restore params--------------------------------------------------------------------
    if readweights==True:
        fname=PATH+"/"+MODEL+('/LSTMWeight/%s_%d_%d_drp%s_batch%d.npy' %(MODEL[:3],N_HIDDEN,LSTM_HIDDEN,drp,B))
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)
    p=1 #patience
    print('start train')
    acc,loss=get_acc_loss(get_out)
    print ('vali acc:%s, vali loss:%s' %(acc,loss))
    
    for i in range(N_EPOCHS):
        #half of train set
        b=0
        batch_x,batch_y=shuffle2lists()
        print(batch_x.shape)
        print(batch_y.shape)
        while b <len(batch_x):
            train(batch_x[b:b+B],batch_y[b:b+B],np.ones((len(batch_y[b:b+B]),TIMESTEP)).astype('int16'))
            b=b+B
            if b%1000==0:
                acc,loss=get_acc_loss(get_out)
                print ('vali acc:%s, vali loss:%s' %(acc,loss))
#save weights------------------------------------------------------
        if loss<lossvali:
            fname=PATH+"/"+MODEL+('/LSTMWeight/%s_%d_%d_drp%s_batch%d.npy' %(MODEL[:3],N_HIDDEN,LSTM_HIDDEN,drp,B))
            weights = lasagne.layers.get_all_param_values(l_out)
            np.save(fname,weights)
            f=open(fname[:-4],'a')
            f.write('vali acc:%s, vali loss:%s\n' %(acc,loss))
            print fname
            f.close()
            lossvali=loss
            accvali=acc
            p=1
        else:
            p+=1
            if p>patience:
                return lossvali,accvali
#****************************************************************************************
def train(ilr=1e-4,elr=1e-6,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=256,times=0,drp=0.5,patience=3):
    lossvali=100
    accvali=0
    rate=ilr
    f=open(PATH+"/"+MODEL+'/LSTMWeight/%s_%d_%d_drp%s_batch%d' %(MODEL[:3],N_HIDDEN,LSTM_HIDDEN,drp,batch_size),'w')
    f.write('learningrate starts from %s\n' %rate)
    f.write('ff_nodes:%d,lstm_nodes:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,LSTM_HIDDEN,drp,batch_size))
    f.close()
    print 'learningrate starts from %s' %rate
    while rate>elr:
        if times==0:
            readweights=0
        else :
            readweights=1
        lossvali,accvali=blstm(rate,lossvali,accvali,batch_size,N_HIDDEN,LSTM_HIDDEN,drp,readweights,patience=patience)
        rate=rate*0.1
        print 'learningrate:%s'%rate
        times+=1

#wks3
#train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=2048,drp=0.3,patience=3)
#train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=128,drp=0.3,patience=3)
train(ilr=1e-5,elr=1e-7,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=1024,times=1,drp=0.4,patience=1)
train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=1024,drp=0.5,patience=1)
train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=1024,drp=0.6,patience=1)
train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=2048,LSTM_HIDDEN=1024,drp=0.7,patience=1)
#wks6
#train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=1024,drp=0.2,patience=3)
#train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=1024,drp=0.1,patience=3)
#train(ilr=1e-4,elr=1e-7,batch_size=128,N_HIDDEN=1024,drp=0.3,patience=3)
