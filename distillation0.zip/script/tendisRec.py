import numpy as np
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
from keras.utils import np_utils
from HTKRW import openx
import tensorflow as tf
import struct
import math
PATH="/home/jango/distillation/"
DIC=PATH+"/shared_babel/phone.dic"
LM=PATH+"/shared_babel/pdnet"
HLIST=PATH+"/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"
NUM_STATES=120
window_size=17
N_EPOCHS = 200
def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def write_htk(features,outputFileName,fs=100,dt=9):
    sampPeriod = 1./fs
    pk =dt & 0x3f
    features=np.atleast_2d(features)
    if pk==0:
        features =features.reshape(-1,1)
    with open(outputFileName,'wb') as fh:
        fh.write(struct.pack(">IIHH",len(features),sampPeriod*1e7,features.shape[1]*4,dt))
        features=features.astype(">f")
        features.tofile(fh)

def RecogWithStateProbs(typ,s=2,pl=2):
    MODEL=PATH+"/teacher/HMM/hmmdefs"
    testlist=PATH+"/%s/feature/list/testdnn.list" %typ

    cmd='echo | julius-4.3.1 -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s %s' %(testlist, HLIST, MODEL, LM, DIC, OPT, s, pl,"-input outprob")
    result=check_output(cmd,shell=1).split("\n")
    #print cmd
    
    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/DNNRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd='HResults -A -z ::: -I '+PATH+'/shared_babel/mlf/alignedtest.mlf -e ::: s_s -e ::: s_e %s /home/jango/distillation/%s/DNNRec/rec.mlf' %(HLIST,typ)
    acc=check_output(cmd,shell=1)
    print acc
    PER=100-float(acc.split("\n")[-3].split(" ")[2].split("=")[1])
    
    print "%s    s: %s, p: %s, PER: %s" %(typ,s,pl,PER)
    return PER

def dnn(typ='student',batch_size=32,N_HIDDEN=2048,LN=4,drp=0.2,patience=5,lamda=0.2,Tem=1.0):
    #------------------------------------------------------------
    #validation data
    skip=window_size/2
    inputs =np.load(PATH+"/teacher/DnnFile/tea_test.npy")[:,:39]
    #make window
    X_TEST=MakeWindows(inputs,window_size).astype('float32')

    #load train targets
    targets = np.load(PATH+"/teacher/DnnFile/tea_test_target.npy")
    Y_TESTdation=np_utils.to_categorical(targets,NUM_STATES)
    Y_TEST=Y_TESTdation[skip:-skip].astype('int16')
    SOFT_TEST=np.load(PATH+"/distrain/soft_targets/soft_test.npy").astype('float32')
    
    #network

    sess = tf.InteractiveSession()
    #variable holders---------------------------
    with tf.name_scope("input") as scope:
        x = tf.placeholder(tf.float32, [None, X_TEST.shape[1]],name='input')
    with tf.name_scope("hard_target") as scope:
        hard_target = tf.placeholder(tf.float32, [None, NUM_STATES],name='hard_target')
    with tf.name_scope("soft_input") as scope:
        s_ = tf.placeholder(tf.float32, [None, NUM_STATES],name='soft_input')
    with tf.name_scope("dropout_keep_prob") as scope:
        kp=tf.placeholder(tf.float32)
    with tf.name_scope("temperature") as scope:
        T=tf.placeholder(tf.float32)
    with tf.name_scope("lamda") as scope:
        L=tf.placeholder(tf.float32)
    global_step = tf.Variable(0, trainable=False)
    #5-------------------------------------------
    with tf.name_scope("hidden_1") as scope:
        W1 = tf.Variable(tf.truncated_normal([X_TEST.shape[1], N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden1_W')
        b1 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden1_b')
        y1 = tf.nn.relu(tf.matmul(x, W1) + b1)
    d1=tf.nn.dropout(y1,kp)
    with tf.name_scope("hidden_2") as scope:
        W2 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden2_W')
        b2 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden2_b')
        y2 = tf.nn.relu(tf.matmul(d1, W2) + b2)
    d2=tf.nn.dropout(y2,kp)
    with tf.name_scope("hidden_3") as scope:
        W3 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden3_W')
        b3 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden3_b')
        y3 = tf.nn.relu(tf.matmul(d2, W3) + b3)
    d3=tf.nn.dropout(y3,kp)
    with tf.name_scope("hidden_4") as scope:
        W4 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden4_W')
        b4 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden4_b')
        y4 = tf.nn.relu(tf.matmul(d3, W4) + b4)
    d4=tf.nn.dropout(y4,kp)
   # with tf.name_scope("hidden_5") as scope:
    #    W5 = tf.Variable(tf.truncated_normal([N_HIDDEN, N_HIDDEN],stddev=1.0 / math.sqrt(float(N_HIDDEN))),name='hidden5_W')
    #    b5 = tf.Variable(tf.constant(0.001, shape=[N_HIDDEN]),name='hidden5_b')
    #    y5 = tf.nn.relu(tf.matmul(d4, W5) + b5)
    #d5=tf.nn.dropout(y5,kp)
    with tf.name_scope("out_layer") as scope:
        W = tf.Variable(tf.truncated_normal([N_HIDDEN, NUM_STATES],stddev=1.0 / math.sqrt(float(NUM_STATES))),name='outlayer_W')
        b = tf.Variable(tf.constant(0.001,shape=[NUM_STATES]),name='outlayer_b')
        y=tf.matmul(d4, W) + b
    with tf.name_scope("hard_output") as scope:
        hard_output= tf.nn.softmax(y)
    with tf.name_scope("soft_output") as scope:
        soft_output= tf.nn.softmax(y/T)
    with tf.name_scope("soft_target") as scope:
        soft_target= tf.nn.softmax(s_/T)

    with tf.name_scope("hard_loss") as scope:
        hardloss= -tf.reduce_sum(hard_target*tf.log(tf.clip_by_value(hard_output,1e-25,1.0)))
        h_loss=tf.scalar_summary('hard_loss', hardloss)
    with tf.name_scope("soft_loss") as scope:
        softloss=-tf.reduce_sum(soft_target*tf.log(tf.clip_by_value(soft_output,1e-25,1.0)))
        s_loss=tf.scalar_summary('soft_loss', softloss)
    with tf.name_scope("weighted_losses") as scope:
        allloss=hardloss * (1-L) + softloss*L*T*T
        a_loss=tf.scalar_summary('total_loss', allloss)
    with tf.name_scope("Accuracy") as scope:
        accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(hard_output,1), tf.argmax(hard_target,1)), tf.float32))
        accuracysum=tf.scalar_summary('accuracy', accuracy)

    init = tf.initialize_all_variables()
    
    sess.run(init)
    saver = tf.train.Saver()
    fname=PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.ckpt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
    saver.restore(sess, fname)
    acc ,loss,soft,al= sess.run([accuracy,hardloss,softloss,allloss], feed_dict={x:X_TEST,hard_target:Y_TEST,s_:SOFT_TEST,kp:1,T:Tem,L:lamda})
    f=open(PATH+('distrain/weights/T_dis'+'_%dL%d_drp%s_batch%d_tem%s_lamda%s.txt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda)),"r")
    alf=f.read()
    f.close()
    def get_train(X):
        y=sess.run(hard_output, feed_dict={x:X,kp:1,T:1,L:0})
        return y
    return get_train,round(acc,4)*100,round(loss,3),round(soft,3),round(al,3),len(alf.split("vali acc:"))-1

def GetStateProbs(typ,batch_size=256,N_HIDDEN=1024,LN=4,drp=0.2,lamda=0.2,Tem=1.0):

    #load state priors
    priors=dict([line.split() for line in open(PATH+"/teacher/StatPrior_train").readlines()])
    #change datatype
    priors=dict([(int(a),float(b)) for a, b in priors.items()])
    #turn into 1D vector in order
    priors=np.array([priors[i] for i in range(len(priors))])
    #get file list
    fnames=open(PATH+"/%s/feature/list/testmfc.list" %typ).readlines()
    #
    #loop all files in filelist
    get_train,acc,loss,soft,al,e=dnn(batch_size=batch_size,N_HIDDEN=N_HIDDEN,LN=LN,drp=drp,lamda=lamda,Tem=Tem)

    for name in fnames:
        #print name[:-1]
        fmfc=openx(name[:-1],'rb',veclen=87)
        data=fmfc.getall()
        #make windows
        vecs=MakeWindows(data,17)
        vecs=vecs.astype('float32')
        #get result from DNN
        probs=get_train(vecs)
        #turn into likelihoods
        log_liks=np.log10(probs/priors)
        #print log_liks.shape
        prob_path=PATH+"/%s/StatePro/" %typ+name.split("/")[-1][:-4]+"llk"
        #print prob_path
        write_htk(log_liks,prob_path)
    #PER=RecogWithStateProbs(typ,0,0)
    #PER=RecogWithStateProbs(typ,2,3)
    PER=RecogWithStateProbs(typ,2,2)
    print "PER:",PER,"acc:",acc,"loss",loss,"soft",soft,"all",al,"epoch:",e
    return PER,acc,loss,e

PER,acc,loss,e=GetStateProbs("student",batch_size=256,N_HIDDEN=1024,LN=4,drp=0.7,lamda=0.8,Tem=1.0)
#f=open('disT2.0.txt',"w")
#for t in [2.0]:
#    for l in [0.2,0.4,0.6,0.8]:
#        PER,acc,loss,e=GetStateProbs("student",batch_size=128,N_HIDDEN=2048,LN=5,drp=0.3,lamda=l,Tem=t)
#        text='tem %s,lamda %s,PER %s,acc %s,loss %s,e %s\n' %(t,l,PER,acc,loss,e)
#        f.write(text)
#f.close()

