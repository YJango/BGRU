import theano
import theano.tensor as T
import lasagne
import numpy as np
from keras.utils import np_utils
from keras.objectives import categorical_crossentropy


NUM_STATES=120
window_size=17
N_EPOCHS = 100

PATH="/home/jango/distillation/student/"
np.random.seed(55)

def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def shufflelists(X_t,y_t):
    ri=np.random.permutation(len(X_t))
    X=X_t[ri]
    y=y_t[ri]
    return X,y

#-------------------------------------------------load data 
skip=window_size / 2
#train data
inputs =np.load(PATH[:-8]+"teacher/DnnFile/tea_train.npy")[:,:39]
#make window
X_TRAIN=MakeWindows(inputs,window_size).astype('float32')

#load train targets
targets = np.load(PATH[:-8]+"teacher/DnnFile/tea_train_target.npy")
Y_train=np_utils.to_categorical(targets,NUM_STATES)
Y_TRAIN=Y_train[skip:-skip].astype('int16')
#------------------------------------------------------------
#validation data
inputs =np.load(PATH[:-8]+"teacher/DnnFile/tea_validation.npy")[:,:39]
#make window
X_VALI=MakeWindows(inputs,window_size).astype('float32')

#load train targets
targets = np.load(PATH[:-8]+"teacher/DnnFile/tea_validation_target.npy")
Y_validation=np_utils.to_categorical(targets,NUM_STATES)
Y_VALI=Y_validation[skip:-skip].astype('int16')

#***********************************************************************
print "train_set:"
print X_TRAIN.shape
print Y_TRAIN.shape
print "validation_set:"
print X_VALI.shape
print Y_VALI.shape

def dnn(learningrate,lossvali,accvali,batch_size=32,N_HIDDEN=2048,LN=4,drp=0.2,readweights=False,patience=5):
    #variable holders
    hard_targets = T.imatrix('hard_target')

    #network

    l_in = lasagne.layers.InputLayer(shape=(None, X_TRAIN.shape[1]))
    #
    l_hidden = lasagne.layers.DenseLayer(
        l_in,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d=lasagne.layers.dropout(l_hidden,drp)
    l_hidden2 = lasagne.layers.DenseLayer(
        d,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d2=lasagne.layers.dropout(l_hidden2,drp)
    l_hidden3 = lasagne.layers.DenseLayer(
        d2,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d3=lasagne.layers.dropout(l_hidden3,drp)
    l_hidden4 = lasagne.layers.DenseLayer(
        d3,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d4=lasagne.layers.dropout(l_hidden4,drp)
    l_hidden5 = lasagne.layers.DenseLayer(
        d4,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d5=lasagne.layers.dropout(l_hidden5,drp)
    l_hidden6 = lasagne.layers.DenseLayer(
        d5,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d6=lasagne.layers.dropout(l_hidden6,drp)
    if LN==3:
        go_in=d3
    elif LN==4:
        go_in=d4
    elif LN==5:
        go_in=d5
    elif LN==6:
        go_in=d6
    else:
        print 'wrong layers number'
    l_out = lasagne.layers.DenseLayer(
        go_in, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.softmax)
    

    #soft for train and eval

    hard_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=False), hard_targets))
    hard_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(
        lasagne.layers.get_output(l_out, deterministic=True), hard_targets))
    
    loss_eval = hard_loss_eval

    loss_train = hard_loss_train

    all_params = lasagne.layers.get_all_params(l_out)

    #updates = lasagne.updates.nesterov_momentum(loss_train, all_params,learning_rate=learningrate)
    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=learningrate)
    #updates = lasagne.updates.rmsprop(loss_train, all_params,learning_rate=learningrate)
    
    train = theano.function([l_in.input_var, hard_targets], loss_train, updates=updates)
    
    #output of network
    #get_train=theano.function([l_in.input_var],lasagne.layers.get_output(l_out, deterministic=True))
    #acc for hard
    get_acc = theano.function([l_in.input_var,hard_targets], T.mean(lasagne.objectives.categorical_accuracy(lasagne.layers.get_output(l_out, deterministic=True), hard_targets)))
    #get two losses
    get_loss = theano.function([l_in.input_var,hard_targets], hard_loss_eval)


    #shuffle
    X,Y = shufflelists(X_TRAIN,Y_TRAIN)

    print X.shape,Y.shape
     

    if readweights==True:
        fname=PATH+('DnnWeight_helpART/stu'+'_%dL%d_drp%s_batch%d.npy' %(LN,N_HIDDEN,drp,batch_size))
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)

    batch_idx = 0
    epoch = 0
    p=1
    while epoch < N_EPOCHS:
        train(X[batch_idx:batch_idx + batch_size],Y[batch_idx:batch_idx + batch_size])
        batch_idx += batch_size
        if batch_idx >= X_TRAIN.shape[0]:
            batch_idx=0
            epoch += 1
            acc=get_acc(X_VALI,Y_VALI)
            loss=get_loss(X_VALI,Y_VALI)
            print ('vali acc:%s, vali loss:%s' %(acc,loss))
            if loss<lossvali:
                fname=PATH+('DnnWeight_helpART/stu'+'_%dL%d_drp%s_batch%d.npy' %(LN,N_HIDDEN,drp,batch_size))
                weights = lasagne.layers.get_all_param_values(l_out)
                np.save(fname,weights)
                print('saved')
                f=open(fname[:-4],'a')
                f.write('vali acc:%s, vali loss:%s\n' %(acc,loss))
                f.close()
                lossvali=loss
                accvali=acc
                p=1
            else:
                p+=1
                if p>patience:
                    return lossvali,accvali

                
            X,Y = shufflelists(X_TRAIN,Y_TRAIN)
            
def train(ilr=1e-4,elr=1e-6,batch_size=64,N_HIDDEN=2048,LN=4,lamda=0.2,Tem=1.0,drp=0.1,patience=3):
    lossvali=100
    accvali=0
    rate=ilr
    f=open(PATH+'DnnWeight_helpART/stu'+'_%dL%d_drp%s_batch%d' %(LN,N_HIDDEN,drp,batch_size),'w')
    f.write('learningrate starts from %s\n' %rate)
    f.write('layers:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,drp,batch_size))
    f.close()
    print 'learningrate starts from %s' %rate
    times=0
    while rate>elr:
        if times==0:
            readweights=0
        else :
            readweights=True
        lossvali,accvali=dnn(rate,lossvali,accvali,batch_size,N_HIDDEN,LN,drp,readweights,patience=patience)
        rate=rate*0.1
        print 'learningrate:%s'%rate
        times+=1

#for l in [3,4,5,6]:
#    for n in [1024,2048,3072]:
#        for b in [128,256,512]:
#            for d in [0.1,0.2,0.3,0.4]:
#                train(ilr=1e-4,elr=1e-6,batch_size=b,N_HIDDEN=n,LN=l,drp=d,patience=3)
train(ilr=1e-4,elr=1e-6,batch_size=128,N_HIDDEN=2048,LN=5,drp=0.3,patience=3)
