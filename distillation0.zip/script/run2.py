import os,sys
path="/home/jango/distillation/script/"

for i in [4,5,6]:
    c="python %ssBLSTM_stu.py %s" %(path,i)
    print c
    os.system(c)

for i in [0,1,2,3,4,5,6]:
    c="python %sRNNETwithPER2.py %s" %(path,i)
    print c
    os.system(c)
