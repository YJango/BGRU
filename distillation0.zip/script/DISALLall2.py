import theano
import theano.tensor as T
import lasagne
import numpy as np
from keras.utils import np_utils
from keras.objectives import categorical_crossentropy
from subprocess import check_output
import tempfile,os,sys
from collections import Counter
from HTKRW import openx
import struct
from lasagne.regularization import l2
NUM_STATES=120
window_size=17
N_EPOCHS = 100
SET=int(sys.argv[1])
TTT=float(sys.argv[2])
LLL=float(sys.argv[3])
PATH="/home/jango/distillation"
DIC="/home/jango/distillation/shared_babel/phone.dic"
LM="/home/jango/distillation/shared_babel/pdnet"
HLIST="/home/jango/distillation/shared_babel/monophones1"
SALIGN='-salign -sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass'
OPT="-sb 160 -b2 60 -s 1000 -m 4000 -quiet -1pass"
JULIUS='julius-4.3.1'
HRESULTS='HResults'
np.random.seed(55)
MODEL='student'
_EPSILON=1e-15
PS=1e-5
def MakeWindows(indata,window_size):
    outdata=[]
    for i in range(indata.shape[0]-window_size+1):
        outdata.append(np.hstack(indata[i:i+window_size]))
    return np.array(outdata)

def shufflelists(x,y,z):
    ri=np.random.permutation(len(x))
    x=x[ri]
    y=y[ri]
    z=z[ri]
    return x,y,z

#**********************************
#       HTK function              *
#**********************************
def write_htk(features,outputFileName,fs=100,dt=9):
    sampPeriod = 1./fs
    pk =dt & 0x3f
    features=np.atleast_2d(features)
    if pk==0:
        features =features.reshape(-1,1)
    with open(outputFileName,'wb') as fh:
        fh.write(struct.pack(">IIHH",len(features),sampPeriod*1e7,features.shape[1]*4,dt))
        features=features.astype(">f")
        features.tofile(fh)
#**********************************
#       julius recognizer         *
#**********************************
def RecogWithStateProbs(typ,s=2,pl=2):
    MODEL=PATH+"/teacher/HMM%s/hmmdefs" %SET
    testlist=PATH+"/%s/feature/list%s/testdnn.list" %(typ,SET)

    cmd='echo | %s -filelist %s -hlist %s -h %s -nlr %s -v %s %s -lmp %s %s %s' %(JULIUS,testlist, HLIST, MODEL, LM, DIC, OPT, s, pl,"-input outprob")
    result=check_output(cmd,shell=1).split("\n")
    #print cmd
    #print cmd
    #print result
    phone=["#!MLF!#\n"]
    f=open(testlist,"r")
    train=f.readlines()
    f.close()
    i=0
    #take result lines
    setname=testlist.split("/")[-1].split("mfc")[0]
    for r in result:
        if 'sentence1' in r:
            fn='"*/'+train[i].split("/")[-1][:-5]+'.rec"\n'
            rec=(("s_s"+r.split("<s>")[1]).replace("</s>","s_e")).replace(" ","\n")+"\n.\n"
            phone.append(fn+rec)
            i+=1
    #write mlf
    fw=open(PATH+"/%s/LSTMRec/rec.mlf" %typ,"w")
    for p in phone:
        fw.write(p)
    fw.close()
    #run HTK HResults
    cmd=HRESULTS+' -A -z ::: -I '+PATH+'/shared_babel/mlf%s/alignedtest.mlf -e ::: s_s -e ::: s_e %s %s/%s/LSTMRec/rec.mlf' %(SET,HLIST,PATH,typ)
    #print cmd
    acc=check_output(cmd,shell=1)
    #print acc
    #print acc
    PER=100-float(acc.split("\n")[-3].split(" ")[2].split("=")[1])
    #print PER
    return PER
#**********************************
#   get results                   *
#**********************************
def GetStateProbs(typ,get_out):
    #load state priors
    priors=dict([line.split() for line in open(PATH+"/teacher/StatPrior%s_train" %SET).readlines()])
    #change datatype
    priors=dict([(int(a),float(b)) for a, b in priors.items()])
    #turn into 1D vector in order
    priors=np.array([priors[i] for i in range(len(priors))])
    #get file list
    fnames=open(PATH+"/%s/feature/list%s/testmfc.list" %(typ,SET)).readlines()
    #
    #loop all files in filelist
    for name in fnames:
        #print name[:-1]
        fmfc=openx(name[:-1],'rb',veclen=39)
        data=fmfc.getall()
        vecs=MakeWindows(data,17).astype('float32')
        #make windows
        #get result from DNN
        probs=get_out(vecs)

        #turn into likelihoods
        log_liks=np.log10(probs/priors)
        #print log_liks.shape
        prob_path=PATH+"/%s/StatePro%s/" %(typ,SET)+name.split("/")[-1][:-4]+"llk"
        #print prob_path
        write_htk(log_liks,prob_path)
    PER=RecogWithStateProbs(typ,2,2)
    return PER

#-------------------------------------------------load data 
skip=window_size / 2

#train data
inputs =np.load(PATH+"/teacher/LSTMFile%s/tea_train_lstm.npy" %SET)
targets = np.load(PATH+"/teacher/LSTMFile%s/tea_train_target_lstm.npy" %SET)
SOFT_TRAIN=np.load(PATH+"/distrain/soft_targets/R%s/soft_train.npy" %SET).astype('float32')
SOFT_VALI=np.load(PATH+"/distrain/soft_targets/R%s/soft_vali.npy" %SET).astype('float32')
s_targets=np.vstack([SOFT_VALI,SOFT_TRAIN])
sen_lens=[]
for t in targets:
    sen_lens.append(len(t))
pointer=0
s_tar=[]
for s in sen_lens:
    s_tar.append(s_targets[pointer:pointer+s])
    pointer+=s
print(len(s_targets),pointer)
s_tar=np.array(s_tar)

X_TRAIN=[]
Y_TRAIN=[]
S_TRAIN=[]
for x,y,s in zip(inputs,targets,s_tar):
    X_TRAIN.append(MakeWindows(x[:,:39],window_size).astype('float32'))
    Y_TRAIN.append(np_utils.to_categorical(y,NUM_STATES)[skip:-skip].astype('int16'))
    S_TRAIN.append(s[skip:-skip].astype('float32'))
inputs=np.vstack(X_TRAIN)
targets=np.vstack(Y_TRAIN)
s_tar=np.vstack(S_TRAIN)
#print len(inputs),len(targets)
X_TRAIN=inputs[len(inputs)/10:]
Y_TRAIN=targets[len(targets)/10:]
X_VALI=inputs[:len(inputs)/10]
Y_VALI=targets[:len(targets)/10]
SOFT_VALI=s_tar[:len(s_tar)/10]
SOFT_TRAIN=s_tar[len(s_tar)/10:]
#***********************************************************************
print "train_set:"
print X_TRAIN.shape
print Y_TRAIN.shape
print SOFT_TRAIN.shape
print "validation_set:"
print X_VALI.shape
print Y_VALI.shape
print SOFT_VALI.shape
if SOFT_TRAIN.shape[0]!=X_TRAIN.shape[0]:
    f=open('wrong.txt',w)
    f.write(X_VALI.shape+'\n'+SOFT_TRAIN.shape+'\n'+SET)
#**********************************
#   evaluation                    *
#**********************************
def validation(get_loss,get_acc):
    loss=0
    acc=0
    ll=0
    while ll<len(Y_VALI):
        loss+=get_loss(X_VALI[ll:ll+128],SOFT_VALI[ll:ll+128])*len(Y_VALI[ll:ll+128])
        acc+=get_acc(X_VALI[ll:ll+128],Y_VALI[ll:ll+128])*len(Y_VALI[ll:ll+128])
        ll+=128
    loss=float(loss)/len(Y_VALI)
    acc=float(acc)/len(Y_VALI)
    return loss,acc
#**********************************
#   display                       *
#**********************************
def display(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
        sys.stdout.write('Epoch:%2.2s(%4.4s) | Train acc:%6.6s loss:%6.6s | Best acc:%6.6s loss:%6.6s | Cur acc:%6.6s loss:%6.6s | PER:%6.6s\r' %(times,round((float(b)/n_samples)*100,1),round(t_acc,4),round(t_loss,4),round(accvali,4),round(lossvali,4),round(acc,4),round(loss,4),round(PER,4)))
        sys.stdout.flush()
#--------------------------------------------------------------------------------------
def writer(fname,acc,loss,accvali,lossvali,b,n_samples,times,PER,t_loss,t_acc):
    f=open(fname[:-4]+'.txt','a')
    f.write('Epoch:%2.2s | Train acc:%6.6s loss:%6.6s | Best acc:%6.6s loss:%6.6s | Cur acc:%6.6s loss:%6.6s | PER:%6.6s\n' %(times,round(t_acc,4),round(t_loss,4),round(accvali,4),round(lossvali,4),round(acc,4),round(loss,4),round(PER,4)))
    f.close()

def dnn(learningrate,lossvali,accvali,batch_size=256,N_HIDDEN=2048,LN=4,drp=0.4,readweights=False,patience=2,lamda=0.6,Tem=1.0):
    #variable holders
    hard_targets = T.matrix('hard_target')
    soft_targets = T.matrix('soft_target')

    l_in = lasagne.layers.InputLayer(shape=(None, X_TRAIN.shape[1]))
    #
    l_hidden = lasagne.layers.DenseLayer(
        l_in,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d=lasagne.layers.dropout(l_hidden,drp)
    l_hidden2 = lasagne.layers.DenseLayer(
        d,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d2=lasagne.layers.dropout(l_hidden2,drp)
    l_hidden3 = lasagne.layers.DenseLayer(
        d2,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d3=lasagne.layers.dropout(l_hidden3,drp)
    l_hidden4 = lasagne.layers.DenseLayer(
        d3,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d4=lasagne.layers.dropout(l_hidden4,drp)
    l_hidden5 = lasagne.layers.DenseLayer(
        d4,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d5=lasagne.layers.dropout(l_hidden5,drp)
    l_hidden6 = lasagne.layers.DenseLayer(
        d5,
        num_units=N_HIDDEN, W=lasagne.init.HeUniform(gain='relu'),b=lasagne.init.Constant(0.001),
        nonlinearity=lasagne.nonlinearities.rectify)
    d6=lasagne.layers.dropout(l_hidden6,drp)
    if LN==3:
        go_in=d3
    elif LN==4:
        go_in=d4
    elif LN==5:
        go_in=d5
    elif LN==6:
        go_in=d6
    else:
        print 'wrong layers number'
    l_out = lasagne.layers.DenseLayer(
        go_in, num_units=NUM_STATES, nonlinearity=lasagne.nonlinearities.linear)
    
    l_out_train = lasagne.layers.get_output(l_out, deterministic=False)
    l_out_eval = lasagne.layers.get_output(l_out, deterministic=True)

    hard_softmax_train = T.exp(l_out_train)/T.sum(T.exp(l_out_train),axis=1, keepdims=True)
    hard_softmax_eval = T.exp(l_out_eval)/T.sum(T.exp(l_out_eval),axis=1, keepdims=True)
    hard_softmax_train=T.clip(hard_softmax_train, _EPSILON, 1.0 - _EPSILON)
    hard_softmax_eval=T.clip(hard_softmax_eval, _EPSILON, 1.0 - _EPSILON)


    soft_softmax_train = T.exp(l_out_train/Tem)/T.sum(T.exp(l_out_train/Tem),axis=1, keepdims=True)
    soft_softmax_eval = T.exp(l_out_eval/Tem)/T.sum(T.exp(l_out_eval/Tem),axis=1, keepdims=True)
    soft_softmax_train=T.clip(soft_softmax_train, _EPSILON, 1.0 - _EPSILON)
    soft_softmax_eval=T.clip(soft_softmax_eval, _EPSILON, 1.0 - _EPSILON)


    soften = T.exp(soft_targets/Tem)/T.sum(T.exp(soft_targets/Tem),axis=1, keepdims=True)

    hard_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(hard_softmax_train, hard_targets))*(1-lamda)
    hard_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(hard_softmax_eval, hard_targets))*(1-lamda)

    soft_loss_train = T.mean(lasagne.objectives.categorical_crossentropy(soft_softmax_train,soften))*lamda*Tem*Tem
    soft_loss_eval = T.mean(lasagne.objectives.categorical_crossentropy(soft_softmax_eval,soften))*lamda*Tem*Tem

    l2_penalty = lasagne.regularization.regularize_layer_params([l_hidden,l_hidden2,l_hidden3,l_hidden4,l_out], l2)*PS
    loss_eval = hard_loss_eval+soft_loss_eval

    loss_train = hard_loss_train+soft_loss_train#+l2_penalty

    all_params = lasagne.layers.get_all_params(l_out)

    updates = lasagne.updates.adam(loss_train, all_params,learning_rate=learningrate)

    get_acc = theano.function([l_in.input_var,hard_targets], T.mean(lasagne.objectives.categorical_accuracy(hard_softmax_train, hard_targets)))
    #get two losses
    get_loss = theano.function([l_in.input_var,hard_targets], hard_loss_eval)
    get_soft_loss=theano.function([l_in.input_var,soft_targets], soft_loss_eval)
    get_all_loss=theano.function([l_in.input_var,hard_targets, soft_targets], loss_eval)
    get_out=theano.function([l_in.input_var],hard_softmax_eval)

    train = theano.function([l_in.input_var, hard_targets, soft_targets], [soft_loss_eval,T.mean(lasagne.objectives.categorical_accuracy(lasagne.layers.get_output(l_out, deterministic=True), hard_targets))], updates=updates)
    #shuffle
    X,Y,S = shufflelists(X_TRAIN,Y_TRAIN,SOFT_TRAIN)

    print X.shape,Y.shape,S.shape


    fname=PATH+('/student/DnnWeight%s/2dis' %SET+'_%dL%d_drp%s_batch%d_T%sL%s.npy' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda))
    if readweights==True:
        weights=np.load(fname)
        lasagne.layers.set_all_param_values(l_out, weights)

    batch_idx = 0
    epoch = 0
    p=1
    loss,acc=validation(get_soft_loss,get_acc)
    n_samples=len(X_TRAIN)
    PER=GetStateProbs(MODEL,get_out)
    t_l=0
    t_a=0
    while epoch < N_EPOCHS:
        t_loss,t_acc=train(X[batch_idx:batch_idx + batch_size],Y[batch_idx:batch_idx + batch_size],S[batch_idx:batch_idx + batch_size])
        batch_idx += batch_size
        t_l+=t_loss*len(Y_TRAIN[batch_idx:batch_idx+batch_size])
        t_a+=t_acc*len(Y_TRAIN[batch_idx:batch_idx+batch_size])
        t_loss=t_l/batch_idx
        t_acc=t_a/batch_idx
        display(fname,acc,loss,accvali,lossvali,batch_idx,n_samples,epoch,PER,t_loss,t_acc)
        if batch_idx >= X_TRAIN.shape[0]:
            batch_idx=0
            epoch += 1
            loss,acc=validation(get_soft_loss,get_acc)
            PER=GetStateProbs(MODEL,get_out)
            t_l=0
            t_a=0
            if accvali<=acc:
                weights = lasagne.layers.get_all_param_values(l_out)
                np.save(fname,weights)
                writer(fname,acc,loss,accvali,lossvali,batch_idx,n_samples,epoch,PER,t_loss,t_acc)
                lossvali=loss
                accvali=acc
                p=1
            else:
                p+=1
                writer(fname,acc,loss,accvali,lossvali,batch_idx,n_samples,epoch,PER,t_loss,t_acc)
                if p>patience:
                    return lossvali,accvali

                
            X,Y,S = shufflelists(X_TRAIN,Y_TRAIN,SOFT_TRAIN)
            
def train(ilr=1e-4,elr=1e-6,batch_size=64,N_HIDDEN=2048,LN=4,lamda=0.6,times=0,Tem=1.0,drp=0.1,patience=3):
    lossvali=100
    accvali=0
    rate=ilr
    f=open(PATH+'/student/DnnWeight%s/2dis' %SET+'_%dL%d_drp%s_batch%d_T%sL%s.txt' %(LN,N_HIDDEN,drp,batch_size,Tem,lamda),'w')
    f.write('learningrate starts from %s\n' %rate)
    f.write('layers:%d, dropout:%s, batch_size: %s\n---------------------------------\n' %(N_HIDDEN,drp,batch_size))
    f.close()
    print 'learningrate starts from %s' %rate
    LR=[1e-4,1e-5,1e-6]
    for LL in LR:
        rate=LL
        print 'learningrate:%s'%rate
        if times==0:
            readweights=0
        else :
            readweights=True
        lossvali,accvali=dnn(rate,lossvali,accvali,batch_size,N_HIDDEN,LN,drp,readweights,patience=patience,Tem=Tem,lamda=lamda)
        times+=1
        patience=patience+2


train(ilr=1e-4,elr=1e-6,batch_size=256,N_HIDDEN=2048,LN=4,drp=0.4,times=0,patience=2,Tem=TTT,lamda=LLL)
