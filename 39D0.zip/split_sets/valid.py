a=set([])
b=0
for i in range(7):
    ft=open("/home/jango/ASR/39D/split_sets/set%s/test" %i,"r")
    lines=ft.readlines()
    ft.close()
    ft=open("/home/jango/ASR/39D/split_sets/set%s/train" %i,"r")
    blines=ft.readlines()
    ft.close()
    a=a|set(lines)
    b=b+len(set(lines)&set(blines))
    ft.close()
    print len(a),b
