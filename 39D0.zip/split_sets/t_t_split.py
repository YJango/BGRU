#split the trainset and testset and validationset
import random

FEMALE=['JW14\n', 'JW16\n', 'JW27\n', 'JW13\n', 'JW21\n', 'JW25\n', 'JW26\n', 'JW30\n', 'JW31\n', 'JW34\n', 'JW35\n', 'JW36\n', 'JW37\n', 'JW39\n', 'JW46\n', 'JW48\n', 'JW49\n', 'JW502\n', 'JW52\n', 'JW54\n', 'JW56\n', 'JW62\n']
MALE=['JW12\n', 'JW18\n', 'JW11\n', 'JW15\n', 'JW19\n', 'JW20\n', 'JW24\n', 'JW28\n', 'JW40\n', 'JW41\n', 'JW43\n', 'JW45\n', 'JW51\n', 'JW53\n', 'JW55\n', 'JW57\n', 'JW58\n', 'JW59\n', 'JW61\n', 'JW63\n']
print len(FEMALE),len(MALE)
fff=random.sample(range(22),22)
mmm=random.sample(range(20),20)

def splits(i):
    fn=open("/home/jango/ASR/39D/split_sets/set%s/train" %i,"w")
    ft=open("/home/jango/ASR/39D/split_sets/set%s/test" %i,"w")
    if i<6:
        ffft=fff[i*3:i*3+3]
        mmmt=mmm[i*3:i*3+3]
    else:
        ffft=fff[-4:]
        mmmt=mmm[-2:]


    fffn=list(set(fff).difference(set(ffft)))
    mmmn=list(set(mmm).difference(set(mmmt)))

    print ffft
    print mmmt
    print fffn
    print mmmn

    for f in ffft:
        ft.write(FEMALE[f])

    for f in fffn:
        fn.write(FEMALE[f])

    for m in mmmt:
        ft.write(MALE[m])

    for m in mmmn:
        fn.write(MALE[m]) 

    fn.close()
    ft.close()
for i in range(7):
    splits(i)
