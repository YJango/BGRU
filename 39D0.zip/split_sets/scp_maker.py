import sys,os
listpath="/home/jango/ASR/withART/ARTfilter/lists/"

def scp(set_name,i):
    fw=open("/home/jango/ASR/39D/split_sets/scp%s/" %i+set_name+'.scp','w')
    f= open("/home/jango/ASR/39D/split_sets/set%s/" %i+set_name,"r")
    lines=f.readlines()
    f.close()
    for n in lines:
        fl=open(listpath+n[:-1]+".list","r")
        lists=fl.readlines()
        f.close()
        for l in lists:
            tname=n[:-1]+"_"+l[:-1]
            fw.write(tname+'\n')
    fw.close()
for i in range(7):
    scp('train',i)
    scp('test',i)
