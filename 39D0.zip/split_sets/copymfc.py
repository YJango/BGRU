import sys,os
setID=int(sys.argv[1])
tarpath="/home/jango/ASR/39D/mfcc/"
source="/home/jango/ASR/new_features/HTKfile/M39_norm"
scppath="/home/jango/ASR/39D/split_sets/scp%s/" %setID
def copymfc(set_name):
    f= open(scppath+set_name+".scp","r")
    lines=f.readlines()
    f.close()
    for n in lines:
        tname=n[:-1]
        c="cp "+source+"/"+tname+".mfc "+tarpath+set_name+"/"+tname+".mfc"
        os.system(c)

copymfc('train')
copymfc('test')
