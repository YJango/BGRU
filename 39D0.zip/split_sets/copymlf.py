import sys,os
setID=int(sys.argv[1])
source="/home/jango/ASR/withART/ARTfilter/ARTmlf"
target="/home/jango/ASR/39D/labels/"
def copymlf(set_name,setID):
    f= open('/home/jango/ASR/39D/split_sets/scp%s/%s' %(setID,set_name)+'.scp',"r")
    lines=f.readlines()
    f.close()
    fm=open(target+set_name+".mlf","w")
    fm.write('#!MLF!#\n')
    for n in lines:
        fz=open(source+"/"+n[:-1],"r")
        fm.write('"*/%s' %n[:-1]+'.lab"\n')
        zline=fz.readlines()
        fz.close()
        for z in zline:
            if z!='sil\n' and z!='sp\n':
                fm.write(z)
        fm.write('.\n')
    fm.close()

copymlf('train',setID)
copymlf('test',setID)
        

