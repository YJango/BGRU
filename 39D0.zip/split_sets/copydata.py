import sys,os
trainpath="/hi-home/jyu/standard/data/train"
testpath="/hi-home/jyu/standard/data/test"
validationpath="/hi-home/jyu/standard/data/validation"
source="/hi-home/jyu/withART/ARTfilter/ARTwav"
listpath="/hi-home/jyu/withART/ARTfilter/lists/"
fn= open("train","r")
nlines=fn.readlines()
for n in nlines:
    flist=open(listpath+n[:-1]+".list","r")
    tlists=flist.readlines()
    flist.close()
    for tlist in tlists:
        tname=n[:-1]+"_"+tlist[:-1]
        c="cp "+source+"/"+tname+".wav "+trainpath+"/"+tname+".wav"
        os.system(c)
ft= open("test","r")
tlines=ft.readlines()
for t in tlines:
    tflist=open(listpath+t[:-1]+".list","r")
    ttlists=tflist.readlines()
    tflist.close()
    for ttlist in ttlists:
        ttname=t[:-1]+"_"+ttlist[:-1]
        c="cp "+source+"/"+ttname+".wav "+testpath+"/"+ttname+".wav"
        os.system(c)
ft.close()
fn.close()
