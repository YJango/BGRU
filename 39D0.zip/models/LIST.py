import os,sys
r="/home/jango/ASR/39D"
teapath='/home/jango/distillation/teacher/feature/data'
stupath='/home/jango/distillation/student/feature/data'
teadnn='/home/jango/distillation/teacher/StatePro'
studnn='/home/jango/distillation/student/StatePro'

def HTKfile(setID):
    testscp=open("%s/split_sets/scp%s/test.scp" %(r,setID),'r')
    test=testscp.readlines()
    testscp.close()
    trainscp=open("%s/split_sets/scp%s/train.scp" %(r,setID),'r')
    train=trainscp.readlines()
    trainscp.close()
    
    #testlists for stu and tea
    ft=open('/home/jango/distillation/teacher/feature/list%s/testmfc.list' %setID,'w')
    fs=open('/home/jango/distillation/student/feature/list%s/testmfc.list' %setID,'w')
    ftd=open('/home/jango/distillation/teacher/feature/list%s/testdnn.list' %setID,'w')
    fsd=open('/home/jango/distillation/student/feature/list%s/testdnn.list' %setID,'w')
    for t in test:
        ft.write('%s/%s.mfc\n' %(teapath,t[:-1]))
        fs.write('%s/%s.mfc\n' %(stupath,t[:-1]))
        ftd.write('%s%s/%s.llk\n' %(teadnn,setID,t[:-1]))
        fsd.write('%s%s/%s.llk\n' %(studnn,setID,t[:-1]))
    ft.close()
    fs.close()
    ftd.close()
    fsd.close()

    #trainlists for stu and tea
    ft=open('/home/jango/distillation/teacher/feature/list%s/trainmfc.list' %setID,'w')
    fs=open('/home/jango/distillation/student/feature/list%s/trainmfc.list' %setID,'w')
    for t in train:
        ft.write('%s/%s.mfc\n' %(teapath,t[:-1]))
        fs.write('%s/%s.mfc\n' %(stupath,t[:-1]))
    ft.close()
    fs.close()
for i in range(7):
    HTKfile(i)
