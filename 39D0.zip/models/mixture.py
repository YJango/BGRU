import os,sys
path="/home/jango/ASR/39D/"
t="0.0 150.0 1000.0"
setID=int(sys.argv[1])
def mixture(fr0m,t0):
    c="mkdir "+path+"models/hmm"+t0+"0 "+path+"models/hmm"+t0+"1 "+path+"models/hmm"+t0+"2 "+path+"models/hmm"+t0+"3 "+path+"models/hmm"+t0+"4"
#+t0+"1 "+t0+"2 "+t0+"3 "+t0+"4"
    print c
    os.system(c)
    #copy files
    c="cp -r "+path+"models/hmm"+fr0m+"4/* "+path+"models/hmm"+t0+"0"

    print c
    os.system(c)
    #copy files
    c="cp -r "+path+"models/hmm"+fr0m+"4/* "+path+"models/hmm"+t0+"0"

    print c
    os.system(c)
    #adapt
    f=open(path+"models/hmm"+t0+"0/mix"+t0+".hed","w")
    f.write("MU "+t0+" {*.state[2-4].mix}")
    f.close()
    c="HHEd -A -C "+path+"models/config -T 1 -H hmm"+t0+"0/hmmdefs -H hmm"+t0+"0/macros hmm"+t0+"0/mix"+t0+".hed "+path+"labels/monophones1"

    print c
    os.system(c)
    c="HERest -A -D -T 1 -C "+path+"models/config -I "+path+"labels/alignedtrain.mlf -t "+t+" -S "+path+"lists/trainmfc.list -H "+path+"models/hmm"+t0+"0"+"/macros -H "+path+"models/hmm"+t0+"0"+"/hmmdefs -M hmm"+t0+"1"+" "+path+"labels/monophones1"

    print c
    os.system(c)
    c="HERest -A -D -T 1 -C "+path+"models/config -I "+path+"labels/alignedtrain.mlf -t "+t+" -S "+path+"lists/trainmfc.list -H "+path+"models/hmm"+t0+"1"+"/macros -H "+path+"models/hmm"+t0+"1"+"/hmmdefs -M hmm"+t0+"2"+" "+path+"labels/monophones1"

    print c
    os.system(c)
    c="HERest -A -D -T 1 -C "+path+"models/config -I "+path+"labels/alignedtrain.mlf -t "+t+" -S "+path+"lists/trainmfc.list -H "+path+"models/hmm"+t0+"2"+"/macros -H "+path+"models/hmm"+t0+"2"+"/hmmdefs -M hmm"+t0+"3"+" "+path+"labels/monophones1"

    print c
    os.system(c)
    c="HERest -A -D -T 1 -C "+path+"models/config -I "+path+"labels/alignedtrain.mlf -t "+t+" -S "+path+"lists/trainmfc.list -H "+path+"models/hmm"+t0+"3"+"/macros -H "+path+"models/hmm"+t0+"3"+"/hmmdefs -M hmm"+t0+"4"+" "+path+"labels/monophones1"
    os.system(c)

    print c


def evaluation(model,s,p):
    c="HVite -A -D -V -C $r/models/config -H hmm"+model+"4/macros -H hmm"+model+"4/hmmdefs -S "+path+"lists/testmfc.list -l '*' -i hmm"+model+"4/recout"+s+".mlf -T 1 -w "+path+"LM/Pdnet -p "+p+" -t "+t+" -s "+s+" "+path+"dictionary/phone.dic "+path+"labels/monophones1 > hmm"+model+"4/log"+p
    print c
    os.system(c)
    c="HResults -A -z ::: -I "+path+"labels/alignedtest.mlf -e ::: s_s -e ::: s_e "+path+"labels/monophones1 hmm"+model+"4/recout"+s+".mlf >hmm"+model+"4/result_s"+s+"_m"+model+"_p"+p  
    print c
    os.system(c)



#fr0m=sys.argv[1]
#t0=sys.argv[2]
#s=sys.argv[3]

s2e=range(2,40,2)
s2e.insert(0,1)
for i,j in zip(s2e[0:-1:1],s2e[1::1]):
    mixture(str(i),str(j))
c="mkdir /home/jango/distillation/student/HMM%s" %setID
os.system(c)
c="cp "+path+"models/hmm384/hmmdefs /home/jango/distillation/student/HMM%s/hmmdefs" %setID
os.system(c)

c="cp /home/jango/ASR/39D/labels/alignedtest.mlf /home/jango/distillation/shared_babel/mlf_sp%s/alignedtest.mlf" %setID
os.system(c)
c="cp /home/jango/ASR/39D/labels/alignedtrain.mlf /home/jango/distillation/shared_babel/mlf_sp%s/alignedtrain.mlf" %setID
os.system(c)
c="cp /home/jango/ASR/39D/labels/alignedvalidation.mlf /home/jango/distillation/shared_babel/mlf_sp%s/alignedvalidation.mlf" %setID
os.system(c)



