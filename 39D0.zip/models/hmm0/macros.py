import os,sys
r="/home/jango/ASR/39D"
vf=open(r+"/models/hmm0/vFloors","r")
vfall=vf.read()
vf.close()

vh=open(r+"/models/hmm0/hmmdefs","r")
vh3lines=vh.readlines()[:3]
vh.close()

fw=open(r+"/models/hmm0/macros","w")
for x in vh3lines:
    fw.write(x)
fw.write(vfall)
fw.close()

