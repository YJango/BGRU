def run():
    fp = open("hmm0/proto","r")
    fm = open("hmm0/monophones0", "r")
    fh = open("hmm0/hmmdefs", "w")
    model = fp.read()
    modelwrite = model.replace("~o\n<STREAMINFO> 1 39\n<VECSIZE> 39<NULLD><USER><DIAGC>\n", '')
    fh.write("~o\n<STREAMINFO> 1 39\n<VECSIZE> 39<NULLD><USER><DIAGC>\n")
    phonemes = fm.readlines()
    for phoneme in phonemes:
        modelin = modelwrite.replace('proto', phoneme.replace('\n',''))
        fh.write(modelin)
    fp.close()
    fm.close()
    fh.close()
if __name__ == "__main__":
    run()
