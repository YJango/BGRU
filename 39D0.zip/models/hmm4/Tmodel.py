import os,sys
r="/home/jango/ASR/39D/models/hmm4/hmmdefs"
f=open(r,"r")
lines=f.readlines()[-28:]
f.close()

lines[0]=lines[0].replace("sil","sp")
lines[2]=lines[2].replace("5","3")
del lines[3]
del lines[4]
del lines[5]
del lines[6]
del lines[7]
del lines[8]
lines[3]=lines[3].replace("3","2")
del lines[9]
del lines[10]
del lines[11]
del lines[12]
del lines[13]
del lines[14]
lines[9]=lines[9].replace("5","3")
lines[10]=' 0.0 1.0 0.0\n'
lines[11]=' 0.0 0.9 0.1\n'
lines[12]=' 0.0 0.0 0.0\n'
del lines[13]
del lines[14]
f=open(r,"a")
for l in lines:
    f.write(l)
f.close()
