import os,sys
r="/home/jango/ASR/39D"

def HTKfile(setID):
    #mfc and lists
    c="rm -r %s/mfcc/*/*" %r
    print c
    os.system(c)
    c="python /home/jango/ASR/39D/split_sets/copymfc.py %s" %setID
    print c
    os.system(c)
    c="python /home/jango/ASR/39D/lists/mfcclists.py"
    print c
    os.system(c)
    #mlf
    c="python /home/jango/ASR/39D/split_sets/copymlf.py %s" %setID
    print c
    os.system(c)
    c="cd /home/jango/ASR/39D/labels"
    print c
    os.system(c)
    c="HLEd -A -D -T 1 -l '*' -d /home/jango/ASR/39D/dictionary/CMU.dic -i /home/jango/ASR/39D/labels/testphone0.mlf /home/jango/ASR/39D/labels/mkphones0.led /home/jango/ASR/39D/labels/test.mlf"
    print c
    os.system(c)
    c="HLEd -A -D -T 1 -l '*' -d /home/jango/ASR/39D/dictionary/CMU.dic -i /home/jango/ASR/39D/labels/trainphone0.mlf /home/jango/ASR/39D/labels/mkphones0.led /home/jango/ASR/39D/labels/train.mlf"
    print c
    os.system(c)
    c="HLEd -A -D -T 1 -l '*' -d /home/jango/ASR/39D/dictionary/CMU.dic -i /home/jango/ASR/39D/labels/trainphone1.mlf /home/jango/ASR/39D/labels/mkphones1.led /home/jango/ASR/39D/labels/train.mlf"
    print c
    os.system(c)

    #Define Prototype Model(models/)
    c="HCompV -A -D -T 1 -C /home/jango/ASR/39D/models/config -f 0.01 -m -S /home/jango/ASR/39D/lists/trainmfc.list -M /home/jango/ASR/39D/models/hmm0 /home/jango/ASR/39D/models/proto"
    print c
    os.system(c)
    c="python /home/jango/ASR/39D/models/hmmdefsMaker.py"
    print c
    os.system(c)
    c="python /home/jango/ASR/39D/models/hmm0/macros.py"
    print c
    os.system(c)
    #train
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I /home/jango/ASR/39D/labels/trainphone0.mlf -t 250.0 150.0 1000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H hmm0/macros -H hmm0/hmmdefs -M hmm1 /home/jango/ASR/39D/labels/monophones0"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I /home/jango/ASR/39D/labels/trainphone0.mlf -t 250.0 150.0 1000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H hmm1/macros -H hmm1/hmmdefs -M hmm2 /home/jango/ASR/39D/labels/monophones0"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I /home/jango/ASR/39D/labels/trainphone0.mlf -t 250.0 150.0 1000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H hmm2/macros -H hmm2/hmmdefs -M hmm3 /home/jango/ASR/39D/labels/monophones0"
    print c
    os.system(c)

    #Fixing the Silence Models(hmm4/)
    c="cp -r /home/jango/ASR/39D/models/hmm3/* /home/jango/ASR/39D/models/hmm4"
    print c
    os.system(c)
    c="python Tmodel.py"
    print c
    os.system(c)
    c="HHEd -A -D -T 1 -H hmm4/macros -H hmm4/hmmdefs -M hmm5 hmm4/sil.hed /home/jango/ASR/39D/labels/monophones1"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I /home/jango/ASR/39D/labels/trainphone1.mlf -t 250.0 150.0 1000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H hmm5/macros -H hmm5/hmmdefs -M hmm6 /home/jango/ASR/39D/labels/monophones1"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I /home/jango/ASR/39D/labels/trainphone1.mlf -t 250.0 150.0 1000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H hmm6/macros -H hmm6/hmmdefs -M hmm7 /home/jango/ASR/39D/labels/monophones1"
    print c
    os.system(c)
    c="HVite -A -D -T 1 -l '*' -o SWT -b s_s -C /home/jango/ASR/39D/models/config -H /home/jango/ASR/39D/models/hmm7/macros -H /home/jango/ASR/39D/models/hmm7/hmmdefs -i /home/jango/ASR/39D/labels/alignedtrain.mlf -m -t 250.0 150.0 1000.0 -y lab -a -I /home/jango/ASR/39D/labels/train.mlf -S /home/jango/ASR/39D/lists/trainmfc.list /home/jango/ASR/39D/dictionary/CMU.dic /home/jango/ASR/39D/labels/monophones1 > HVite_log_train"
    print c
    os.system(c)
    c="HVite -A -D -T 1 -l '*' -o SWT -b s_s -C /home/jango/ASR/39D/models/config -H /home/jango/ASR/39D/models/hmm7/macros -H /home/jango/ASR/39D/models/hmm7/hmmdefs -i /home/jango/ASR/39D/labels/alignedtest.mlf -m -t 250.0 150.0 1000.0 -y lab -a -I /home/jango/ASR/39D/labels/test.mlf -S /home/jango/ASR/39D/lists/testmfc.list /home/jango/ASR/39D/dictionary/CMU.dic /home/jango/ASR/39D/labels/monophones1 > HVite_log_test"
    print c
    os.system(c)
    c="HVite -A -D -T 1 -l '*' -o SWT -b s_s -C /home/jango/ASR/39D/models/config -H /home/jango/ASR/39D/models/hmm7/macros -H /home/jango/ASR/39D/models/hmm7/hmmdefs -i /home/jango/ASR/39D/labels/alignedvalidation.mlf -m -t 250.0 150.0 1000.0 -y lab -a -I /home/jango/ASR/39D/labels/validation.mlf -S /home/jango/ASR/39D/lists/validationmfc.list /home/jango/ASR/39D/dictionary/CMU.dic /home/jango/ASR/39D/labels/monophones1 > HVite_log_validation"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I  /home/jango/ASR/39D/labels/alignedtrain.mlf -t 250.0 150.0 3000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H /home/jango/ASR/39D/models/hmm7/macros -H /home/jango/ASR/39D/models/hmm7/hmmdefs -M hmm8 /home/jango/ASR/39D/labels/monophones1"
    print c
    os.system(c)
    c="HERest -A -D -T 1 -C /home/jango/ASR/39D/models/config -I  /home/jango/ASR/39D/labels/alignedtrain.mlf -t 250.0 150.0 3000.0 -S /home/jango/ASR/39D/lists/trainmfc.list -H /home/jango/ASR/39D/models/hmm8/macros -H /home/jango/ASR/39D/models/hmm8/hmmdefs -M hmm9 /home/jango/ASR/39D/labels/monophones1"
    print c
    os.system(c)

HTKfile(0)



