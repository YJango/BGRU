def run(filename):
    f=open(filename, "r")
    f2=open(filename+".dic", "w")
    values=list(f)
    f.close()
    values=[ value[:-1] for value in values]
    g=sorted(values)
    for i in g:
        f2.write(i)
        f2.write("\n")
    f.close()
    f2.close() 
run("dict")

