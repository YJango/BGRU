import os 
import sys
def run(set_name): 
    f = open(tar+set_name+"mfc.list", "w")
    list_dirs = os.walk(Path+set_name) 
    for root, dirs, files in list_dirs:   
        for fs in files: 
            if ".mfc" in fs:
                row = root + "/" + fs + "\n"
                f.write(row)
    f.close()



if __name__ == "__main__":
    Path = '/home/jango/ASR/39D/mfcc/'
    tar = '/home/jango/ASR/39D/lists/'
    run('train')
    run('test')
